!function(ay,ai,ao){function an(b,a){return typeof b===a
}function ak(){var j,f,k,h,d,b,g;
for(var c in X){if(X.hasOwnProperty(c)){if(j=[],f=X[c],f.name&&(j.push(f.name.toLowerCase()),f.options&&f.options.aliases&&f.options.aliases.length)){for(k=0;
k<f.options.aliases.length;
k++){j.push(f.options.aliases[k].toLowerCase())
}}for(h=an(f.fn,"function")?f.fn():f.fn,d=0;
d<j.length;
d++){b=j[d],g=b.split("."),1===g.length?ab[g[0]]=h:(!ab[g[0]]||ab[g[0]] instanceof Boolean||(ab[g[0]]=new Boolean(ab[g[0]])),ab[g[0]][g[1]]=h),aD.push((h?"":"no-")+g.join("-"))
}}}}function au(b){var a=af.className,d=ab._config.classPrefix||"";
if(G&&(a=a.baseVal),ab._config.enableJSClass){var c=new RegExp("(^|\\s)"+d+"no-js(\\s|$)");
a=a.replace(c,"$1"+d+"js$2")
}ab._config.enableClasses&&(a+=" "+d+b.join(" "+d),G?af.className.baseVal=a:af.className=a)
}function aC(c,a){if("object"==typeof c){for(var f in c){J(c,f)&&aC(f,c[f])
}}else{c=c.toLowerCase();
var d=c.split("."),b=ab[d[0]];
if(2==d.length&&(b=b[d[1]]),"undefined"!=typeof b){return ab
}a="function"==typeof a?a():a,1==d.length?ab[d[0]]=a:(!ab[d[0]]||ab[d[0]] instanceof Boolean||(ab[d[0]]=new Boolean(ab[d[0]])),ab[d[0]][d[1]]=a),au([(a&&0!=a?"":"no-")+d.join("-")]),ab._trigger(c,a)
}return ab
}function aj(){return"function"!=typeof ai.createElement?ai.createElement(arguments[0]):G?ai.createElementNS.call(ai,"http://www.w3.org/2000/svg",arguments[0]):ai.createElement.apply(ai,arguments)
}function ah(a){return a.replace(/([a-z])-([a-z])/g,function(c,b,d){return b+d.toUpperCase()
}).replace(/^-/,"")
}function aq(a){return a.replace(/([A-Z])/g,function(c,b){return"-"+b.toLowerCase()
}).replace(/^ms-/,"-ms-")
}function ax(){var a=ai.body;
return a||(a=aj(G?"svg":"body"),a.fake=!0),a
}function aA(m,h,g,b){var k,t,v,j,s="modernizr",q=aj("div"),f=ax();
if(parseInt(g,10)){for(;
g--;
){v=aj("div"),v.id=b?b[g]:s+(g+1),q.appendChild(v)
}}return k=aj("style"),k.type="text/css",k.id="s"+s,(f.fake?f:q).appendChild(k),f.appendChild(q),k.styleSheet?k.styleSheet.cssText=m:k.appendChild(ai.createTextNode(m)),q.id=s,f.fake&&(f.style.background="",f.style.overflow="hidden",j=af.style.overflow,af.style.overflow="hidden",af.appendChild(f)),t=h(q,m),f.fake?(f.parentNode.removeChild(f),af.style.overflow=j,af.offsetHeight):q.parentNode.removeChild(q),!!t
}function az(b,a){return !!~(""+b).indexOf(a)
}function am(b,d){var c=b.length;
if("CSS" in ay&&"supports" in ay.CSS){for(;
c--;
){if(ay.CSS.supports(aq(b[c]),d)){return !0
}}return !1
}if("CSSSupportsRule" in ay){for(var a=[];
c--;
){a.push("("+aq(b[c])+":"+d+")")
}return a=a.join(" or "),aA("@supports ("+a+") { #modernizr { position: absolute; } }",function(f){return"absolute"==getComputedStyle(f,null).position
})
}return ao
}function ag(b,a){return function(){return b.apply(a,arguments)
}
}function ap(d,b,f){var c;
for(var a in d){if(d[a] in b){return f===!1?d[a]:(c=b[d[a]],an(c,"function")?ag(c,f||b):c)
}}return !1
}function av(q,z,b,k){function w(){p&&(delete D.style,delete D.modElem)
}if(k=!an(k,"undefined")&&k,!an(b,"undefined")){var j=am(q,b);
if(!an(j,"undefined")){return j
}}for(var p,s,x,d,n,u=["modernizr","tspan","samp"];
!D.style&&u.length;
){p=!0,D.modElem=aj(u.shift()),D.style=D.modElem.style
}for(x=q.length,s=0;
x>s;
s++){if(d=q[s],n=D.style[d],az(d,"-")&&(d=ah(d)),D.style[d]!==ao){if(k||an(b,"undefined")){return w(),"pfx"!=z||d
}try{D.style[d]=b
}catch(o){}if(D.style[d]!=n){return w(),"pfx"!=z||d
}}}return w(),!1
}function ad(h,d,j,g,c){var b=h.charAt(0).toUpperCase()+h.slice(1),f=(h+" "+I.join(b+" ")+b).split(" ");
return an(d,"string")||an(d,"undefined")?av(f,d,g,c):(f=(h+" "+aB.join(b+" ")+b).split(" "),ap(f,d,j))
}function aw(b,a,c){return ad(b,ao,ao,a,c)
}var aD=[],X=[],F={_version:"3.3.1",_config:{classPrefix:"delta",enableClasses:!0,enableJSClass:!0,usePrefixes:!0},_q:[],on:function(b,a){var c=this;
setTimeout(function(){a(c[b])
},0)
},addTest:function(b,a,c){X.push({name:b,fn:a,options:c})
},addAsyncTest:function(a){X.push({name:null,fn:a})
}},ab=function(){};
ab.prototype=F,ab=new ab,ab.addTest("cookies",function(){try{ai.cookie="cookietest=1";
var a=-1!=ai.cookie.indexOf("cookietest=");
return ai.cookie="cookietest=1; expires=Thu, 01-Jan-1970 00:00:01 GMT",a
}catch(b){return !1
}}),ab.addTest("cors","XMLHttpRequest" in ay&&"withCredentials" in new XMLHttpRequest),ab.addTest("customevent","CustomEvent" in ay&&"function"==typeof ay.CustomEvent),ab.addTest("eventlistener","addEventListener" in ay),ab.addTest("geolocation","geolocation" in navigator),ab.addTest("history",function(){var a=navigator.userAgent;
return(-1===a.indexOf("Android 2.")&&-1===a.indexOf("Android 4.0")||-1===a.indexOf("Mobile Safari")||-1!==a.indexOf("Chrome")||-1!==a.indexOf("Windows Phone"))&&(ay.history&&"pushState" in ay.history)
}),ab.addTest("ie8compat",!ay.addEventListener&&!!ai.documentMode&&7===ai.documentMode),ab.addTest("json","JSON" in ay&&"parse" in JSON&&"stringify" in JSON);
var ae=F._config.usePrefixes?" -webkit- -moz- -o- -ms- ".split(" "):["",""];
F._prefixes=ae;
var af=ai.documentElement,G="svg"===af.nodeName.toLowerCase(),V="Moz O ms Webkit",aB=F._config.usePrefixes?V.toLowerCase().split(" "):[];
F._domPrefixes=aB;
var J;
!function(){var a={}.hasOwnProperty;
J=an(a,"undefined")||an(a.call,"undefined")?function(c,b){return b in c&&an(c.constructor.prototype[b],"undefined")
}:function(b,c){return a.call(b,c)
}
}(),F._l={},F.on=function(b,a){this._l[b]||(this._l[b]=[]),this._l[b].push(a),ab.hasOwnProperty(b)&&setTimeout(function(){ab._trigger(b,ab[b])
},0)
},F._trigger=function(b,a){if(this._l[b]){var c=this._l[b];
setTimeout(function(){var d,f;
for(d=0;
d<c.length;
d++){(f=c[d])(a)
}},0),delete this._l[b]
}},ab._q.push(function(){F.addTest=aC
});
var I=F._config.usePrefixes?V.split(" "):[];
F._cssomPrefixes=I;
var Q=function(f){var j,h=ae.length,d=ay.CSSRule;
if("undefined"==typeof d){return ao
}if(!f){return !1
}if(f=f.replace(/^@/,""),j=f.replace(/-/g,"_").toUpperCase()+"_RULE",j in d){return"@"+f
}for(var b=0;
h>b;
b++){var g=ae[b],c=g.toUpperCase()+"_"+j;
if(c in d){return"@-"+g.toLowerCase()+"-"+f
}}return !1
};
F.atRule=Q;
var ar=function(){function a(f,c){var d;
return !!f&&(c&&"string"!=typeof c||(c=aj(c||"div")),f="on"+f,d=f in c,!d&&b&&(c.setAttribute||(c=aj("div")),c.setAttribute(f,""),d="function"==typeof c[f],c[f]!==ao&&(c[f]=ao),c.removeAttribute(f)),d)
}var b=!("onblur" in ai.documentElement);
return a
}();
F.hasEvent=ar,ab.addTest("inputsearchevent",ar("search"));
var Z=function(d,b){var g=!1,f=aj("div"),c=f.style;
if(d in c){var a=aB.length;
for(c[d]=b,g=c[d];
a--&&!g;
){c[d]="-"+aB[a]+"-"+b,g=c[d]
}}return""===g&&(g=!1),g
};
F.prefixedCSSValue=Z,ab.addTest("audio",function(){var b=aj("audio"),a=!1;
try{(a=!!b.canPlayType)&&(a=new Boolean(a),a.ogg=b.canPlayType('audio/ogg; codecs="vorbis"').replace(/^no$/,""),a.mp3=b.canPlayType('audio/mpeg; codecs="mp3"').replace(/^no$/,""),a.opus=b.canPlayType('audio/ogg; codecs="opus"')||b.canPlayType('audio/webm; codecs="opus"').replace(/^no$/,""),a.wav=b.canPlayType('audio/wav; codecs="1"').replace(/^no$/,""),a.m4a=(b.canPlayType("audio/x-m4a;")||b.canPlayType("audio/aac;")).replace(/^no$/,""))
}catch(c){}return a
}),ab.addTest("canvas",function(){var a=aj("canvas");
return !(!a.getContext||!a.getContext("2d"))
}),ab.addTest("contenteditable",function(){if("contentEditable" in af){var a=aj("div");
return a.contentEditable=!0,"true"===a.contentEditable
}}),aC("htmlimports","import" in aj("link"));
var U=aj("input"),K="autocomplete autofocus list placeholder max min multiple pattern required step".split(" "),ac={};
ab.input=function(a){for(var c=0,b=a.length;
b>c;
c++){ac[a[c]]=!!(a[c] in U)
}return ac.list&&(ac.list=!(!aj("datalist")||!ay.HTMLDataListElement)),ac
}(K);
var H=function(){var a=ay.matchMedia||ay.msMatchMedia;
return a?function(b){var c=a(b);
return c&&c.matches||!1
}:function(b){var c=!1;
return aA("@media "+b+" { #modernizr { position: absolute; } }",function(d){c="absolute"==(ay.getComputedStyle?ay.getComputedStyle(d,null):d.currentStyle).position
}),c
}
}();
F.mq=H;
var at=F.testStyles=aA;
ab.addTest("hiddenscroll",function(){return at("#modernizr {width:100px;height:100px;overflow:scroll}",function(a){return a.offsetWidth===a.clientWidth
})
});
var al={elem:aj("modernizr")};
ab._q.push(function(){delete al.elem
});
var D={style:al.elem.style};
ab._q.unshift(function(){delete D.style
}),F.testProp=function(b,a,c){return av([b],ao,a,c)
},F.testAllProps=ad;
var aa=F.prefixed=function(b,a,c){return 0===b.indexOf("@")?Q(b):(-1!=b.indexOf("-")&&(b=ah(b)),a?ad(b,a,c):ad(b,"pfx"))
};
F.prefixedCSS=function(b){var a=aa(b);
return a&&aq(a)
},ab.addTest("forcetouch",function(){return !!ar(aa("mouseforcewillbegin",ay,!1),ay)&&(MouseEvent.WEBKIT_FORCE_AT_MOUSE_DOWN&&MouseEvent.WEBKIT_FORCE_AT_FORCE_MOUSE_DOWN)
}),ab.addTest("fullscreen",!(!aa("exitFullscreen",ai,!1)&&!aa("cancelFullScreen",ai,!1))),F.testAllProps=aw,ak(),au(aD),delete F.addTest,delete F.addAsyncTest;
for(var Y=0;
Y<ab._q.length;
Y++){ab._q[Y]()
}ay.Modernizr=ab
}(window,document);
!function(d){var c=navigator.userAgent;
d.HTMLPictureElement&&/ecko/.test(c)&&c.match(/rv\:(\d+)/)&&RegExp.$1<45&&addEventListener("resize",function(){var a,o=document.createElement("source"),n=function(g){var f,p,h=g.parentNode;
"PICTURE"===h.nodeName.toUpperCase()?(f=o.cloneNode(),h.insertBefore(f,h.firstElementChild),setTimeout(function(){h.removeChild(f)
})):(!g._pfLastSize||g.offsetWidth>g._pfLastSize)&&(g._pfLastSize=g.offsetWidth,p=g.sizes,g.sizes+=",100vw",setTimeout(function(){g.sizes=p
}))
},m=function(){var g,f=document.querySelectorAll("picture > img, img[srcset][sizes]");
for(g=0;
g<f.length;
g++){n(f[g])
}},l=function(){clearTimeout(a),a=setTimeout(m,99)
},k=d.matchMedia&&matchMedia("(orientation: landscape)"),j=function(){l(),k&&k.addListener&&k.addListener(l)
};
return o.srcset="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==",/^[c|i]|d$/.test(document.readyState||"")?j():document.addEventListener("DOMContentLoaded",j),l
}())
}(window),function(a3,a2,a1){function a0(b){return" "===b||"\t"===b||"\n"===b||"\f"===b||"\r"===b
}function aZ(a,g){var f=new a3.Image;
return f.onerror=function(){aB[a]=!1,a4()
},f.onload=function(){aB[a]=1===f.width,a4()
},f.src=g,"pending"
}function aY(){ao=!1,al=a3.devicePixelRatio,an={},am={},aL.DPR=al||1,ak.width=Math.max(a3.innerWidth||0,aE.clientWidth),ak.height=Math.max(a3.innerHeight||0,aE.clientHeight),ak.vw=ak.width/100,ak.vh=ak.height/100,aM=[ak.height,ak.width,al].join("-"),ak.em=aL.getEmValue(),ak.rem=ak.em
}function aX(k,j,q,p){var o,n,m,l;
return"saveData"===aA.algorithm?k>2.7?l=q+1:(n=j-q,o=Math.pow(k-0.6,1.5),m=n*o,p&&(m+=0.1*o),l=k+m):l=q>1?Math.sqrt(k*j):k,l>q
}function aW(g){var f,j=aL.getSet(g),h=!1;
"pending"!==j&&(h=aM,j&&(f=aL.setRes(j),aL.applySetCandidate(f,g))),g[aL.ns].evaled=h
}function aV(d,c){return d.res-c.res
}function aU(g,f,j){var h;
return !j&&f&&(j=g[aL.ns].sets,j=j&&j[j.length-1]),h=aT(f,j),h&&(f=aL.makeUrl(f),g[aL.ns].curSrc=f,g[aL.ns].curCan=h,h.res||aC(h,h.set.sizes)),h
}function aT(g,f){var k,j,h;
if(g&&f){for(h=aL.parseSet(f),g=aL.makeUrl(g),k=0;
k<h.length;
k++){if(g===aL.makeUrl(h[k].url)){j=h[k];
break
}}}return j
}function aS(j,h){var o,n,m,l,k=j.getElementsByTagName("source");
for(o=0,n=k.length;
n>o;
o++){m=k[o],m[aL.ns]=!0,l=m.getAttribute("srcset"),l&&h.push({srcset:l,media:m.getAttribute("media"),type:m.getAttribute("type"),sizes:m.getAttribute("sizes")})
}}function aR(z,y){function x(a){var g,f=a.exec(z.substring(o));
return f?(g=f[0],o+=g.length,g):void 0
}function w(){var G,F,E,D,C,B,A,n,h,g=!1,b={};
for(D=0;
D<t.length;
D++){C=t[D],B=C[C.length-1],A=C.substring(0,C.length-1),n=parseInt(A,10),h=parseFloat(A),ad.test(A)&&"w"===B?((G||F)&&(g=!0),0===n?g=!0:G=n):ac.test(A)&&"x"===B?((G||F||E)&&(g=!0),0>h?g=!0:F=h):ad.test(A)&&"h"===B?((E||F)&&(g=!0),0===n?g=!0:E=n):g=!0
}g||(b.url=u,G&&(b.w=G),F&&(b.d=F),E&&(b.h=E),E||F||G||(b.d=1),1===b.d&&(y.has1x=!0),b.set=y,d.push(b))
}function v(){for(x(ah),s="",r="in descriptor";
;
){if(q=z.charAt(o),"in descriptor"===r){if(a0(q)){s&&(t.push(s),s="",r="after descriptor")
}else{if(","===q){return o+=1,s&&t.push(s),void w()
}if("("===q){s+=q,r="in parens"
}else{if(""===q){return s&&t.push(s),void w()
}s+=q
}}}else{if("in parens"===r){if(")"===q){s+=q,r="in descriptor"
}else{if(""===q){return t.push(s),void w()
}s+=q
}}else{if("after descriptor"===r){if(a0(q)){}else{if(""===q){return void w()
}r="in descriptor",o-=1
}}}}o+=1
}}for(var u,t,s,r,q,p=z.length,o=0,d=[];
;
){if(x(ag),o>=p){return d
}u=x(af),t=[],","===u.slice(-1)?(u=u.replace(ae,""),w()):v()
}}function aQ(v){function u(E){function D(){A&&(z.push(A),A="")
}function C(){z[0]&&(y.push(z),z=[])
}for(var B,A="",z=[],y=[],x=0,w=0,l=!1;
;
){if(B=E.charAt(w),""===B){return D(),C(),y
}if(l){if("*"===B&&"/"===E[w+1]){l=!1,w+=2,D();
continue
}w+=1
}else{if(a0(B)){if(E.charAt(w-1)&&a0(E.charAt(w-1))||!A){w+=1;
continue
}if(0===x){D(),w+=1;
continue
}B=" "
}else{if("("===B){x+=1
}else{if(")"===B){x-=1
}else{if(","===B){D(),C(),w+=1;
continue
}if("/"===B&&"*"===E.charAt(w+1)){l=!0,w+=2;
continue
}}}}A+=B,w+=1
}}}function t(b){return !!(m.test(b)&&parseFloat(b)>=0)||(!!d.test(b)||("0"===b||"-0"===b||"+0"===b))
}var s,r,q,p,o,n,m=/^(?:[+-]?[0-9]+|[0-9]*\.[0-9]+)(?:[eE][+-]?[0-9]+)?(?:ch|cm|em|ex|in|mm|pc|pt|px|rem|vh|vmin|vmax|vw)$/i,d=/^calc\((?:[0-9a-z \.\+\-\*\/\(\)]+)\)$/i;
for(r=u(v),q=r.length,s=0;
q>s;
s++){if(p=r[s],o=p[p.length-1],t(o)){if(n=o,p.pop(),0===p.length){return n
}if(p=p.join(" "),aL.matchesMedia(p)){return n
}}}return"100vw"
}a2.createElement("picture");
var aP,aO,aN,aM,aL={},aK=!1,aJ=function(){},aI=a2.createElement("img"),aH=aI.getAttribute,aG=aI.setAttribute,aF=aI.removeAttribute,aE=a2.documentElement,aB={},aA={algorithm:""},az="data-pfsrc",ay=az+"set",ax=navigator.userAgent,aw=/rident/.test(ax)||/ecko/.test(ax)&&ax.match(/rv\:(\d+)/)&&RegExp.$1>35,av="currentSrc",au=/\s+\+?\d+(e\d+)?w/,at=/(\([^)]+\))?\s*(.+)/,ar=a3.picturefillCFG,aq="position:absolute;left:0;visibility:hidden;display:block;padding:0;border:none;font-size:1em;width:1em;overflow:hidden;clip:rect(0px, 0px, 0px, 0px)",ap="font-size:100%!important;",ao=!0,an={},am={},al=a3.devicePixelRatio,ak={px:1,"in":96},aj=a2.createElement("a"),ai=!1,ah=/^[ \t\n\r\u000c]+/,ag=/^[, \t\n\r\u000c]+/,af=/^[^ \t\n\r\u000c]+/,ae=/[,]+$/,ad=/^\d+$/,ac=/^-?(?:[0-9]+|[0-9]*\.[0-9]+)(?:[eE][+-]?[0-9]+)?$/,ab=function(g,f,j,h){g.addEventListener?g.addEventListener(f,j,h||!1):g.attachEvent&&g.attachEvent("on"+f,j)
},aD=function(d){var c={};
return function(a){return a in c||(c[a]=d(a)),c[a]
}
},a5=function(){var f=/^([\d\.]+)(em|vw|px)$/,d=function(){for(var j=arguments,h=0,k=j[0];
++h in j;
){k=k.replace(j[h],j[++h])
}return k
},g=aD(function(b){return"return "+d((b||"").toLowerCase(),/\band\b/g,"&&",/,/g,"||",/min-([a-z-\s]+):/g,"e.$1>=",/max-([a-z-\s]+):/g,"e.$1<=",/calc([^)]+)/g,"($1)",/(\d+[\.]*[\d]*)([a-z]+)/g,"($1 * e.$2)",/^(?!(e.[a-z]|[0-9\.&=|><\+\-\*\(\)\/])).*/gi,"")+";"
});
return function(a,j){var h;
if(!(a in an)){if(an[a]=!1,j&&(h=a.match(f))){an[a]=h[1]*ak[h[2]]
}else{try{an[a]=new Function("e",g(a))(ak)
}catch(c){}}}return an[a]
}
}(),aC=function(d,c){return d.w?(d.cWidth=aL.calcListLength(c||"100vw"),d.res=d.w/d.cWidth):d.res=d.d,d
},a4=function(b){if(aK){var k,j,h,g=b||{};
if(g.elements&&1===g.elements.nodeType&&("IMG"===g.elements.nodeName.toUpperCase()?g.elements=[g.elements]:(g.context=g.elements,g.elements=null)),k=g.elements||aL.qsa(g.context||a2,g.reevaluate||g.reselect?aL.sel:aL.selShort),h=k.length){for(aL.setupRun(g),ai=!0,j=0;
h>j;
j++){aL.fillImg(k[j],g)
}aL.teardownRun(g)
}}};
aP=a3.console&&console.warn?function(b){console.warn(b)
}:aJ,av in aI||(av="src"),aB["image/jpeg"]=!0,aB["image/gif"]=!0,aB["image/png"]=!0,aB["image/svg+xml"]=a2.implementation.hasFeature("http://www.w3.org/TR/SVG11/feature#Image","1.1"),aL.ns=("pf"+(new Date).getTime()).substr(0,9),aL.supSrcset="srcset" in aI,aL.supSizes="sizes" in aI,aL.supPicture=!!a3.HTMLPictureElement,aL.supSrcset&&aL.supPicture&&!aL.supSizes&&!function(b){aI.srcset="data:,a",b.src="data:,a",aL.supSrcset=aI.complete===b.complete,aL.supPicture=aL.supSrcset&&aL.supPicture
}(a2.createElement("img")),aL.supSrcset&&!aL.supSizes?!function(){var b="data:image/gif;base64,R0lGODlhAgABAPAAAP///wAAACH5BAAAAAAALAAAAAACAAEAAAICBAoAOw==",h="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==",g=a2.createElement("img"),f=function(){var c=g.width;
2===c&&(aL.supSizes=!0),aN=aL.supSrcset&&!aL.supSizes,aK=!0,setTimeout(a4)
};
g.onload=f,g.onerror=f,g.setAttribute("sizes","9px"),g.srcset=h+" 1w,"+b+" 9w",g.src=h
}():aK=!0,aL.selShort="picture>img,img[srcset]",aL.sel=aL.selShort,aL.cfg=aA,aL.DPR=al||1,aL.u=ak,aL.types=aB,aL.setSize=aJ,aL.makeUrl=aD(function(b){return aj.href=b,aj.href
}),aL.qsa=function(d,c){return"querySelector" in d?d.querySelectorAll(c):[]
},aL.matchesMedia=function(){return a3.matchMedia&&(matchMedia("(min-width: 0.1em)")||{}).matches?aL.matchesMedia=function(b){return !b||matchMedia(b).matches
}:aL.matchesMedia=aL.mMQ,aL.matchesMedia.apply(this,arguments)
},aL.mMQ=function(b){return !b||a5(b)
},aL.calcLength=function(d){var c=a5(d,!0)||!1;
return 0>c&&(c=!1),c
},aL.supportsType=function(b){return !b||aB[b]
},aL.parseSize=aD(function(d){var c=(d||"").match(at);
return{media:c&&c[1],length:c&&c[2]}
}),aL.parseSet=function(b){return b.cands||(b.cands=aR(b.srcset,b)),b.cands
},aL.getEmValue=function(){var b;
if(!aO&&(b=a2.body)){var h=a2.createElement("div"),g=aE.style.cssText,f=b.style.cssText;
h.style.cssText=aq,aE.style.cssText=ap,b.style.cssText=ap,b.appendChild(h),aO=h.offsetWidth,b.removeChild(h),aO=parseFloat(aO,10),aE.style.cssText=g,b.style.cssText=f
}return aO||16
},aL.calcListLength=function(d){if(!(d in am)||aA.uT){var c=aL.calcLength(aQ(d));
am[d]=c?c:ak.width
}return am[d]
},aL.setRes=function(g){var f;
if(g){f=aL.parseSet(g);
for(var j=0,h=f.length;
h>j;
j++){aC(f[j],g.sizes)
}}return f
},aL.setRes.res=aC,aL.applySetCandidate=function(A,z){if(A.length){var y,x,w,v,u,t,s,r,q,j=z[aL.ns],g=aL.DPR;
if(t=j.curSrc||z[av],s=j.curCan||aU(z,t,A[0].set),s&&s.set===A[0].set&&(q=aw&&!z.complete&&s.res-0.1>g,q||(s.cached=!0,s.res>=g&&(u=s))),!u){for(A.sort(aV),v=A.length,u=A[v-1],x=0;
v>x;
x++){if(y=A[x],y.res>=g){w=x-1,u=A[w]&&(q||t!==aL.makeUrl(y.url))&&aX(A[w].res,y.res,g,A[w].cached)?A[w]:y;
break
}}}u&&(r=aL.makeUrl(u.url),j.curSrc=r,j.curCan=u,r!==t&&aL.setSrc(z,u),aL.setSize(z))
}},aL.setSrc=function(f,d){var g;
f.src=d.url,"image/svg+xml"===d.set.type&&(g=f.style.width,f.style.width=f.offsetWidth+1+"px",f.offsetWidth+1&&(f.style.width=g))
},aL.getSet=function(h){var g,m,l,k=!1,j=h[aL.ns].sets;
for(g=0;
g<j.length&&!k;
g++){if(m=j[g],m.srcset&&aL.matchesMedia(m.media)&&(l=aL.supportsType(m.type))){"pending"===l&&(m=l),k=m;
break
}}return k
},aL.parseSets=function(r,q,p){var o,n,m,l,k=q&&"PICTURE"===q.nodeName.toUpperCase(),c=r[aL.ns];
(c.src===a1||p.src)&&(c.src=aH.call(r,"src"),c.src?aG.call(r,az,c.src):aF.call(r,az)),(c.srcset===a1||p.srcset||!aL.supSrcset||r.srcset)&&(o=aH.call(r,"srcset"),c.srcset=o,l=!0),c.sets=[],k&&(c.pic=!0,aS(q,c.sets)),c.srcset?(n={srcset:c.srcset,sizes:aH.call(r,"sizes")},c.sets.push(n),m=(aN||c.src)&&au.test(c.srcset||""),m||!c.src||aT(c.src,n)||n.has1x||(n.srcset+=", "+c.src,n.cands.push({url:c.src,d:1,set:n}))):c.src&&c.sets.push({srcset:c.src,sizes:null}),c.curCan=null,c.curSrc=a1,c.supported=!(k||n&&!aL.supSrcset||m&&!aL.supSizes),l&&aL.supSrcset&&!c.supported&&(o?(aG.call(r,ay,o),r.srcset=""):aF.call(r,ay)),c.supported&&!c.srcset&&(!c.src&&r.src||r.src!==aL.makeUrl(c.src))&&(null===c.src?r.removeAttribute("src"):r.src=c.src),c.parsed=!0
},aL.fillImg=function(g,f){var j,h=f.reselect||f.reevaluate;
g[aL.ns]||(g[aL.ns]={}),j=g[aL.ns],(h||j.evaled!==aM)&&((!j.parsed||f.reevaluate)&&aL.parseSets(g,g.parentNode,f),j.supported?j.evaled=aM:aW(g))
},aL.setupRun=function(){(!ai||ao||al!==a3.devicePixelRatio)&&aY()
},aL.supPicture?(a4=aJ,aL.fillImg=aJ):!function(){var n,m=a3.attachEvent?/d$|^c/:/d$|^c|^i/,l=function(){var c=a2.readyState||"";
k=setTimeout(l,"loading"===c?200:999),a2.body&&(aL.fillImgs(),n=n||m.test(c),n&&clearTimeout(k))
},k=setTimeout(l,a2.body?9:99),j=function(g,f){var p,o,h=function(){var c=new Date-o;
f>c?p=setTimeout(h,f-c):(p=null,g())
};
return function(){o=new Date,p||(p=setTimeout(h,f))
}
},b=aE.clientHeight,a=function(){ao=Math.max(a3.innerWidth||0,aE.clientWidth)!==ak.width||aE.clientHeight!==b,b=aE.clientHeight,ao&&aL.fillImgs()
};
ab(a3,"resize",j(a,99)),ab(a2,"readystatechange",l)
}(),aL.picturefill=a4,aL.fillImgs=a4,aL.teardownRun=aJ,a4._=aL,a3.picturefillCFG={pf:aL,push:function(d){var c=d.shift();
"function"==typeof aL[c]?aL[c].apply(aL,d):(aA[c]=d[0],ai&&aL.fillImgs({reselect:!0}))
}};
for(;
ar&&ar.length;
){a3.picturefillCFG.push(ar.shift())
}a3.picturefill=a4,"object"==typeof module&&"object"==typeof module.exports?module.exports=a4:"function"==typeof define&&define.amd&&define("picturefill",function(){return a4
}),aL.supPicture||(aB["image/webp"]=aZ("image/webp","data:image/webp;base64,UklGRkoAAABXRUJQVlA4WAoAAAAQAAAAAAAAAAAAQUxQSAwAAAABBxAR/Q9ERP8DAABWUDggGAAAADABAJ0BKgEAAQADADQlpAADcAD++/1QAA=="))
}(window,document),function(b){var a=function(c){return c.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")
};
b.picturefillBackgroundOptions={selector:"picturefill-background",backgroundSize:"cover",backgroundRepeat:"no-repeat",backgroundPosition:"50% 50%"},b.picturefillBackground=function(){for(var o=b.document.getElementsByClassName(b.picturefillBackgroundOptions.selector),k=0,n=o.length;
k<n;
k++){for(var d=o[k].getElementsByTagName("span"),m=[],h=0,l=d.length;
h<l;
h++){var c=d[h].getAttribute("data-src"),f=d[h].getAttribute("data-media");
c&&(!f||b.matchMedia&&b.matchMedia(f).matches)&&m.push(c)
}if(m.length){c=m.pop();
var g=new RegExp(a(c));
g.test(o[k].style.backgroundImage)||(o[k].style.backgroundImage="url('"+c+"')",o[k].style.backgroundSize=b.picturefillBackgroundOptions.backgroundSize,o[k].style.backgroundRepeat=b.picturefillBackgroundOptions.backgroundRepeat,o[k].style.backgroundPosition=b.picturefillBackgroundOptions.backgroundPosition)
}}},b.addEventListener?(b.addEventListener("load",b.picturefillBackground,!1),b.addEventListener("resize",b.picturefillBackground,!1),b.addEventListener("DOMContentLoaded",function(){b.picturefillBackground(),b.removeEventListener("load",b.picturefillBackground,!1)
},!1)):b.attachEvent&&b.attachEvent("onload",b.picturefillBackground)
}(this);
if("undefined"==typeof jQuery){throw new Error("Bootstrap's JavaScript requires jQuery")
}+function(d){var c=d.fn.jquery.split(" ")[0].split(".");
if(c[0]<2&&c[1]<9||1==c[0]&&9==c[1]&&c[2]<1||c[0]>2){throw new Error("Bootstrap's JavaScript requires jQuery version 1.9.1 or higher, but lower than version 3")
}}(jQuery),+function(d){function c(){var g=document.createElement("bootstrap"),f={WebkitTransition:"webkitTransitionEnd",MozTransition:"transitionend",OTransition:"oTransitionEnd otransitionend",transition:"transitionend"};
for(var h in f){if(void 0!==g.style[h]){return{end:f[h]}
}}return !1
}d.fn.emulateTransitionEnd=function(a){var h=!1,g=this;
d(this).one("bsTransitionEnd",function(){h=!0
});
var f=function(){h||d(g).trigger(d.support.transition.end)
};
return setTimeout(f,a),this
},d(function(){d.support.transition=c(),d.support.transition&&(d.event.special.bsTransitionEnd={bindType:d.support.transition.end,delegateType:d.support.transition.end,handle:function(a){return d(a.target).is(this)?a.handleObj.handler.apply(this,arguments):void 0
}})
})
}(jQuery),+function(g){function f(a){return this.each(function(){var d=g(this),b=d.data("bs.alert");
b||d.data("bs.alert",b=new j(this)),"string"==typeof a&&b[a].call(d)
})
}var k='[data-dismiss="alert"]',j=function(a){g(a).on("click",k,this.close)
};
j.VERSION="3.3.6",j.TRANSITION_DURATION=150,j.prototype.close=function(a){function n(){d.detach().trigger("closed.bs.alert").remove()
}var m=g(this),l=m.attr("data-target");
l||(l=m.attr("href"),l=l&&l.replace(/.*(?=#[^\s]*$)/,""));
var d=g(l);
a&&a.preventDefault(),d.length||(d=m.closest(".alert")),d.trigger(a=g.Event("close.bs.alert")),a.isDefaultPrevented()||(d.removeClass("in"),g.support.transition&&d.hasClass("fade")?d.one("bsTransitionEnd",n).emulateTransitionEnd(j.TRANSITION_DURATION):n())
};
var h=g.fn.alert;
g.fn.alert=f,g.fn.alert.Constructor=j,g.fn.alert.noConflict=function(){return g.fn.alert=h,this
},g(document).on("click.bs.alert.data-api",k,j.prototype.close)
}(jQuery),+function(g){function f(a){return this.each(function(){var k=g(this),c=k.data("bs.button"),b="object"==typeof a&&a;
c||k.data("bs.button",c=new j(this,b)),"toggle"==a?c.toggle():a&&c.setState(a)
})
}var j=function(a,c){this.$element=g(a),this.options=g.extend({},j.DEFAULTS,c),this.isLoading=!1
};
j.VERSION="3.3.6",j.DEFAULTS={loadingText:"loading..."},j.prototype.setState=function(a){var n="disabled",m=this.$element,l=m.is("input")?"val":"html",k=m.data();
a+="Text",null==k.resetText&&m.data("resetText",m[l]()),setTimeout(g.proxy(function(){m[l](null==k[a]?this.options[a]:k[a]),"loadingText"==a?(this.isLoading=!0,m.addClass(n).attr(n,n)):this.isLoading&&(this.isLoading=!1,m.removeClass(n).removeAttr(n))
},this),0)
},j.prototype.toggle=function(){var k=!0,d=this.$element.closest('[data-toggle="buttons"]');
if(d.length){var l=this.$element.find("input");
"radio"==l.prop("type")?(l.prop("checked")&&(k=!1),d.find(".active").removeClass("active"),this.$element.addClass("active")):"checkbox"==l.prop("type")&&(l.prop("checked")!==this.$element.hasClass("active")&&(k=!1),this.$element.toggleClass("active")),l.prop("checked",this.$element.hasClass("active")),k&&l.trigger("change")
}else{this.$element.attr("aria-pressed",!this.$element.hasClass("active")),this.$element.toggleClass("active")
}};
var h=g.fn.button;
g.fn.button=f,g.fn.button.Constructor=j,g.fn.button.noConflict=function(){return g.fn.button=h,this
},g(document).on("click.bs.button.data-api",'[data-toggle^="button"]',function(b){var a=g(b.target);
a.hasClass("btn")||(a=a.closest(".btn")),f.call(a,"toggle"),g(b.target).is('input[type="radio"]')||g(b.target).is('input[type="checkbox"]')||b.preventDefault()
}).on("focus.bs.button.data-api blur.bs.button.data-api",'[data-toggle^="button"]',function(a){g(a.target).closest(".btn").toggleClass("focus",/^focus(in)?$/.test(a.type))
})
}(jQuery),+function(g){function f(a){return this.each(function(){var m=g(this),l=m.data("bs.carousel"),c=g.extend({},k.DEFAULTS,m.data(),"object"==typeof a&&a),b="string"==typeof a?a:c.slide;
l||m.data("bs.carousel",l=new k(this,c)),"number"==typeof a?l.to(a):b?l[b]():c.interval&&l.pause().cycle()
})
}var k=function(a,d){this.$element=g(a),this.$indicators=this.$element.find(".carousel-indicators"),this.options=d,this.paused=null,this.sliding=null,this.interval=null,this.$active=null,this.$items=null,this.options.keyboard&&this.$element.on("keydown.bs.carousel",g.proxy(this.keydown,this)),"hover"==this.options.pause&&!("ontouchstart" in document.documentElement)&&this.$element.on("mouseenter.bs.carousel",g.proxy(this.pause,this)).on("mouseleave.bs.carousel",g.proxy(this.cycle,this))
};
k.VERSION="3.3.6",k.TRANSITION_DURATION=600,k.DEFAULTS={interval:5000,pause:"hover",wrap:!0,keyboard:!0},k.prototype.keydown=function(b){if(!/input|textarea/i.test(b.target.tagName)){switch(b.which){case 37:this.prev();
break;
case 39:this.next();
break;
default:return
}b.preventDefault()
}},k.prototype.cycle=function(a){return a||(this.paused=!1),this.interval&&clearInterval(this.interval),this.options.interval&&!this.paused&&(this.interval=setInterval(g.proxy(this.next,this),this.options.interval)),this
},k.prototype.getItemIndex=function(b){return this.$items=b.parent().children(".item"),this.$items.index(b||this.$active)
},k.prototype.getItemForDirection=function(m,l){var q=this.getItemIndex(l),p="prev"==m&&0===q||"next"==m&&q==this.$items.length-1;
if(p&&!this.options.wrap){return l
}var o="prev"==m?-1:1,n=(q+o)%this.$items.length;
return this.$items.eq(n)
},k.prototype.to=function(l){var d=this,m=this.getItemIndex(this.$active=this.$element.find(".item.active"));
return l>this.$items.length-1||0>l?void 0:this.sliding?this.$element.one("slid.bs.carousel",function(){d.to(l)
}):m==l?this.pause().cycle():this.slide(l>m?"next":"prev",this.$items.eq(l))
},k.prototype.pause=function(a){return a||(this.paused=!0),this.$element.find(".next, .prev").length&&g.support.transition&&(this.$element.trigger(g.support.transition.end),this.cycle(!0)),this.interval=clearInterval(this.interval),this
},k.prototype.next=function(){return this.sliding?void 0:this.slide("next")
},k.prototype.prev=function(){return this.sliding?void 0:this.slide("prev")
},k.prototype.slide=function(v,u){var t=this.$element.find(".item.active"),s=u||this.getItemForDirection(v,t),r=this.interval,q="next"==v?"left":"right",p=this;
if(s.hasClass("active")){return this.sliding=!1
}var o=s[0],n=g.Event("slide.bs.carousel",{relatedTarget:o,direction:q});
if(this.$element.trigger(n),!n.isDefaultPrevented()){if(this.sliding=!0,r&&this.pause(),this.$indicators.length){this.$indicators.find(".active").removeClass("active");
var c=g(this.$indicators.children()[this.getItemIndex(s)]);
c&&c.addClass("active")
}var a=g.Event("slid.bs.carousel",{relatedTarget:o,direction:q});
return g.support.transition&&this.$element.hasClass("slide")?(s.addClass(v),s[0].offsetWidth,t.addClass(q),s.addClass(q),t.one("bsTransitionEnd",function(){s.removeClass([v,q].join(" ")).addClass("active"),t.removeClass(["active",q].join(" ")),p.sliding=!1,setTimeout(function(){p.$element.trigger(a)
},0)
}).emulateTransitionEnd(k.TRANSITION_DURATION)):(t.removeClass("active"),s.addClass("active"),this.sliding=!1,this.$element.trigger(a)),r&&this.cycle(),this
}};
var j=g.fn.carousel;
g.fn.carousel=f,g.fn.carousel.Constructor=k,g.fn.carousel.noConflict=function(){return g.fn.carousel=j,this
};
var h=function(o){var n,m=g(this),l=g(m.attr("data-target")||(n=m.attr("href"))&&n.replace(/.*(?=#[^\s]+$)/,""));
if(l.hasClass("carousel")){var b=g.extend({},l.data(),m.data()),a=m.attr("data-slide-to");
a&&(b.interval=!1),f.call(l,b),a&&l.data("bs.carousel").to(a),o.preventDefault()
}};
g(document).on("click.bs.carousel.data-api","[data-slide]",h).on("click.bs.carousel.data-api","[data-slide-to]",h),g(window).on("load",function(){g('[data-ride="carousel"]').each(function(){var a=g(this);
f.call(a,a.data())
})
})
}(jQuery),+function(g){function f(a){var m,l=a.attr("data-target")||(m=a.attr("href"))&&m.replace(/.*(?=#[^\s]+$)/,"");
return g(l)
}function k(a){return this.each(function(){var l=g(this),d=l.data("bs.collapse"),b=g.extend({},j.DEFAULTS,l.data(),"object"==typeof a&&a);
!d&&b.toggle&&/show|hide/.test(a)&&(b.toggle=!1),d||l.data("bs.collapse",d=new j(this,b)),"string"==typeof a&&d[a]()
})
}var j=function(a,d){this.$element=g(a),this.options=g.extend({},j.DEFAULTS,d),this.$trigger=g('[data-toggle="collapse"][href="#'+a.id+'"],[data-toggle="collapse"][data-target="#'+a.id+'"]'),this.transitioning=null,this.options.parent?this.$parent=this.getParent():this.addAriaAndCollapsedClass(this.$element,this.$trigger),this.options.toggle&&this.toggle()
};
j.VERSION="3.3.6",j.TRANSITION_DURATION=350,j.DEFAULTS={toggle:!0},j.prototype.dimension=function(){var b=this.$element.hasClass("width");
return b?"width":"height"
},j.prototype.show=function(){if(!this.transitioning&&!this.$element.hasClass("in")){var a,n=this.$parent&&this.$parent.children(".panel").children(".in, .collapsing");
if(!(n&&n.length&&(a=n.data("bs.collapse"),a&&a.transitioning))){var m=g.Event("show.bs.collapse");
if(this.$element.trigger(m),!m.isDefaultPrevented()){n&&n.length&&(k.call(n,"hide"),a||n.data("bs.collapse",null));
var l=this.dimension();
this.$element.removeClass("collapse").addClass("collapsing")[l](0).attr("aria-expanded",!0),this.$trigger.removeClass("collapsed").attr("aria-expanded",!0),this.transitioning=1;
var d=function(){this.$element.removeClass("collapsing").addClass("collapse in")[l](""),this.transitioning=0,this.$element.trigger("shown.bs.collapse")
};
if(!g.support.transition){return d.call(this)
}var c=g.camelCase(["scroll",l].join("-"));
this.$element.one("bsTransitionEnd",g.proxy(d,this)).emulateTransitionEnd(j.TRANSITION_DURATION)[l](this.$element[0][c])
}}}},j.prototype.hide=function(){if(!this.transitioning&&this.$element.hasClass("in")){var a=g.Event("hide.bs.collapse");
if(this.$element.trigger(a),!a.isDefaultPrevented()){var l=this.dimension();
this.$element[l](this.$element[l]())[0].offsetHeight,this.$element.addClass("collapsing").removeClass("collapse in").attr("aria-expanded",!1),this.$trigger.addClass("collapsed").attr("aria-expanded",!1),this.transitioning=1;
var d=function(){this.transitioning=0,this.$element.removeClass("collapsing").addClass("collapse").trigger("hidden.bs.collapse")
};
return g.support.transition?void this.$element[l](0).one("bsTransitionEnd",g.proxy(d,this)).emulateTransitionEnd(j.TRANSITION_DURATION):d.call(this)
}}},j.prototype.toggle=function(){this[this.$element.hasClass("in")?"hide":"show"]()
},j.prototype.getParent=function(){return g(this.options.parent).find('[data-toggle="collapse"][data-parent="'+this.options.parent+'"]').each(g.proxy(function(l,b){var a=g(b);
this.addAriaAndCollapsedClass(f(a),a)
},this)).end()
},j.prototype.addAriaAndCollapsedClass=function(l,d){var m=l.hasClass("in");
l.attr("aria-expanded",m),d.toggleClass("collapsed",!m).attr("aria-expanded",m)
};
var h=g.fn.collapse;
g.fn.collapse=k,g.fn.collapse.Constructor=j,g.fn.collapse.noConflict=function(){return g.fn.collapse=h,this
},g(document).on("click.bs.collapse.data-api",'[data-toggle="collapse"]',function(m){var l=g(this);
l.attr("data-target")||m.preventDefault();
var c=f(l),b=c.data("bs.collapse"),a=b?"toggle":l.data();
k.call(c,a)
})
}(jQuery),+function(k){function j(a){var g=a.attr("data-target");
g||(g=a.attr("href"),g=g&&/#[A-Za-z]/.test(g)&&g.replace(/.*(?=#[^\s]*$)/,""));
var f=g&&k(g);
return f&&f.length?f:a.parent()
}function q(a){a&&3===a.which||(k(o).remove(),k(n).each(function(){var g=k(this),c=j(g),b={relatedTarget:this};
c.hasClass("open")&&(a&&"click"==a.type&&/input|textarea/i.test(a.target.tagName)&&k.contains(c[0],a.target)||(c.trigger(a=k.Event("hide.bs.dropdown",b)),a.isDefaultPrevented()||(g.attr("aria-expanded","false"),c.removeClass("open").trigger(k.Event("hidden.bs.dropdown",b)))))
}))
}function p(a){return this.each(function(){var f=k(this),b=f.data("bs.dropdown");
b||f.data("bs.dropdown",b=new m(this)),"string"==typeof a&&b[a].call(f)
})
}var o=".dropdown-backdrop",n='[data-toggle="dropdown"]',m=function(a){k(a).on("click.bs.dropdown",this.toggle)
};
m.VERSION="3.3.6",m.prototype.toggle=function(s){var r=k(this);
if(!r.is(".disabled, :disabled")){var c=j(r),b=c.hasClass("open");
if(q(),!b){"ontouchstart" in document.documentElement&&!c.closest(".navbar-nav").length&&k(document.createElement("div")).addClass("dropdown-backdrop").insertAfter(k(this)).on("click",q);
var a={relatedTarget:this};
if(c.trigger(s=k.Event("show.bs.dropdown",a)),s.isDefaultPrevented()){return
}r.trigger("focus").attr("aria-expanded","true"),c.toggleClass("open").trigger(k.Event("shown.bs.dropdown",a))
}return !1
}},m.prototype.keydown=function(u){if(/(38|40|27|32)/.test(u.which)&&!/input|textarea/i.test(u.target.tagName)){var t=k(this);
if(u.preventDefault(),u.stopPropagation(),!t.is(".disabled, :disabled")){var s=j(t),r=s.hasClass("open");
if(!r&&27!=u.which||r&&27==u.which){return 27==u.which&&s.find(n).trigger("focus"),t.trigger("click")
}var f=" li:not(.disabled):visible a",b=s.find(".dropdown-menu"+f);
if(b.length){var a=b.index(u.target);
38==u.which&&a>0&&a--,40==u.which&&a<b.length-1&&a++,~a||(a=0),b.eq(a).trigger("focus")
}}}};
var l=k.fn.dropdown;
k.fn.dropdown=p,k.fn.dropdown.Constructor=m,k.fn.dropdown.noConflict=function(){return k.fn.dropdown=l,this
},k(document).on("click.bs.dropdown.data-api",q).on("click.bs.dropdown.data-api",".dropdown form",function(b){b.stopPropagation()
}).on("click.bs.dropdown.data-api",n,m.prototype.toggle).on("keydown.bs.dropdown.data-api",n,m.prototype.keydown).on("keydown.bs.dropdown.data-api",".dropdown-menu",m.prototype.keydown)
}(jQuery),+function(g){function f(a,c){return this.each(function(){var k=g(this),d=k.data("bs.modal"),b=g.extend({},j.DEFAULTS,k.data(),"object"==typeof a&&a);
d||k.data("bs.modal",d=new j(this,b)),"string"==typeof a?d[a](c):b.show&&d.show(c)
})
}var j=function(a,d){this.options=d,this.$body=g(document.body),this.$element=g(a),this.$dialog=this.$element.find(".modal-dialog"),this.$backdrop=null,this.isShown=null,this.originalBodyPad=null,this.scrollbarWidth=0,this.ignoreBackdropClick=!1,this.options.remote&&this.$element.find(".modal-content").load(this.options.remote,g.proxy(function(){this.$element.trigger("loaded.bs.modal")
},this))
};
j.VERSION="3.3.6",j.TRANSITION_DURATION=300,j.BACKDROP_TRANSITION_DURATION=150,j.DEFAULTS={backdrop:!0,keyboard:!0,show:!0},j.prototype.toggle=function(b){return this.isShown?this.hide():this.show(b)
},j.prototype.show=function(a){var k=this,c=g.Event("show.bs.modal",{relatedTarget:a});
this.$element.trigger(c),this.isShown||c.isDefaultPrevented()||(this.isShown=!0,this.checkScrollbar(),this.setScrollbar(),this.$body.addClass("modal-open"),this.escape(),this.resize(),this.$element.on("click.dismiss.bs.modal",'[data-dismiss="modal"]',g.proxy(this.hide,this)),this.$dialog.on("mousedown.dismiss.bs.modal",function(){k.$element.one("mouseup.dismiss.bs.modal",function(d){g(d.target).is(k.$element)&&(k.ignoreBackdropClick=!0)
})
}),this.backdrop(function(){var d=g.support.transition&&k.$element.hasClass("fade");
k.$element.parent().length||k.$element.appendTo(k.$body),k.$element.show().scrollTop(0),k.adjustDialog(),d&&k.$element[0].offsetWidth,k.$element.addClass("in"),k.enforceFocus();
var b=g.Event("shown.bs.modal",{relatedTarget:a});
d?k.$dialog.one("bsTransitionEnd",function(){k.$element.trigger("focus").trigger(b)
}).emulateTransitionEnd(j.TRANSITION_DURATION):k.$element.trigger("focus").trigger(b)
}))
},j.prototype.hide=function(a){a&&a.preventDefault(),a=g.Event("hide.bs.modal"),this.$element.trigger(a),this.isShown&&!a.isDefaultPrevented()&&(this.isShown=!1,this.escape(),this.resize(),g(document).off("focusin.bs.modal"),this.$element.removeClass("in").off("click.dismiss.bs.modal").off("mouseup.dismiss.bs.modal"),this.$dialog.off("mousedown.dismiss.bs.modal"),g.support.transition&&this.$element.hasClass("fade")?this.$element.one("bsTransitionEnd",g.proxy(this.hideModal,this)).emulateTransitionEnd(j.TRANSITION_DURATION):this.hideModal())
},j.prototype.enforceFocus=function(){g(document).off("focusin.bs.modal").on("focusin.bs.modal",g.proxy(function(b){this.$element[0]===b.target||this.$element.has(b.target).length||this.$element.trigger("focus")
},this))
},j.prototype.escape=function(){this.isShown&&this.options.keyboard?this.$element.on("keydown.dismiss.bs.modal",g.proxy(function(b){27==b.which&&this.hide()
},this)):this.isShown||this.$element.off("keydown.dismiss.bs.modal")
},j.prototype.resize=function(){this.isShown?g(window).on("resize.bs.modal",g.proxy(this.handleUpdate,this)):g(window).off("resize.bs.modal")
},j.prototype.hideModal=function(){var b=this;
this.$element.hide(),this.backdrop(function(){b.$body.removeClass("modal-open"),b.resetAdjustments(),b.resetScrollbar(),b.$element.trigger("hidden.bs.modal")
})
},j.prototype.removeBackdrop=function(){this.$backdrop&&this.$backdrop.remove(),this.$backdrop=null
},j.prototype.backdrop=function(a){var m=this,l=this.$element.hasClass("fade")?"fade":"";
if(this.isShown&&this.options.backdrop){var k=g.support.transition&&l;
if(this.$backdrop=g(document.createElement("div")).addClass("modal-backdrop "+l).appendTo(this.$body),this.$element.on("click.dismiss.bs.modal",g.proxy(function(b){return this.ignoreBackdropClick?void (this.ignoreBackdropClick=!1):void (b.target===b.currentTarget&&("static"==this.options.backdrop?this.$element[0].focus():this.hide()))
},this)),k&&this.$backdrop[0].offsetWidth,this.$backdrop.addClass("in"),!a){return
}k?this.$backdrop.one("bsTransitionEnd",a).emulateTransitionEnd(j.BACKDROP_TRANSITION_DURATION):a()
}else{if(!this.isShown&&this.$backdrop){this.$backdrop.removeClass("in");
var c=function(){m.removeBackdrop(),a&&a()
};
g.support.transition&&this.$element.hasClass("fade")?this.$backdrop.one("bsTransitionEnd",c).emulateTransitionEnd(j.BACKDROP_TRANSITION_DURATION):c()
}else{a&&a()
}}},j.prototype.handleUpdate=function(){this.adjustDialog()
},j.prototype.adjustDialog=function(){var b=this.$element[0].scrollHeight>document.documentElement.clientHeight;
this.$element.css({paddingLeft:!this.bodyIsOverflowing&&b?this.scrollbarWidth:"",paddingRight:this.bodyIsOverflowing&&!b?this.scrollbarWidth:""})
},j.prototype.resetAdjustments=function(){this.$element.css({paddingLeft:"",paddingRight:""})
},j.prototype.checkScrollbar=function(){var d=window.innerWidth;
if(!d){var c=document.documentElement.getBoundingClientRect();
d=c.right-Math.abs(c.left)
}this.bodyIsOverflowing=document.body.clientWidth<d,this.scrollbarWidth=this.measureScrollbar()
},j.prototype.setScrollbar=function(){var b=parseInt(this.$body.css("padding-right")||0,10);
this.originalBodyPad=document.body.style.paddingRight||"",this.bodyIsOverflowing&&this.$body.css("padding-right",b+this.scrollbarWidth)
},j.prototype.resetScrollbar=function(){this.$body.css("padding-right",this.originalBodyPad)
},j.prototype.measureScrollbar=function(){var d=document.createElement("div");
d.className="modal-scrollbar-measure",this.$body.append(d);
var c=d.offsetWidth-d.clientWidth;
return this.$body[0].removeChild(d),c
};
var h=g.fn.modal;
g.fn.modal=f,g.fn.modal.Constructor=j,g.fn.modal.noConflict=function(){return g.fn.modal=h,this
},g(document).on("click.bs.modal.data-api",'[data-toggle="modal"]',function(m){var l=g(this),k=l.attr("href"),b=g(l.attr("data-target")||k&&k.replace(/.*(?=#[^\s]+$)/,"")),a=b.data("bs.modal")?"toggle":g.extend({remote:!/#/.test(k)&&k},b.data(),l.data());
l.is("a")&&m.preventDefault(),b.one("show.bs.modal",function(c){c.isDefaultPrevented()||b.one("hidden.bs.modal",function(){l.is(":visible")&&l.trigger("focus")
})
}),f.call(b,a,this)
})
}(jQuery),+function(g){function f(a){return this.each(function(){var k=g(this),c=k.data("bs.tooltip"),b="object"==typeof a&&a;
(c||!/destroy|hide/.test(a))&&(c||k.data("bs.tooltip",c=new j(this,b)),"string"==typeof a&&c[a]())
})
}var j=function(d,c){this.type=null,this.options=null,this.enabled=null,this.timeout=null,this.hoverState=null,this.$element=null,this.inState=null,this.init("tooltip",d,c)
};
j.VERSION="3.3.6",j.TRANSITION_DURATION=150,j.DEFAULTS={animation:!0,placement:"top",selector:!1,template:'<div class="tooltip" role="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>',trigger:"hover focus",title:"",delay:0,html:!1,container:!1,viewport:{selector:"body",padding:0}},j.prototype.init=function(a,q,p){if(this.enabled=!0,this.type=a,this.$element=g(q),this.options=this.getOptions(p),this.$viewport=this.options.viewport&&g(g.isFunction(this.options.viewport)?this.options.viewport.call(this,this.$element):this.options.viewport.selector||this.options.viewport),this.inState={click:!1,hover:!1,focus:!1},this.$element[0] instanceof document.constructor&&!this.options.selector){throw new Error("`selector` option must be specified when initializing "+this.type+" on the window.document object!")
}for(var o=this.options.trigger.split(" "),n=o.length;
n--;
){var m=o[n];
if("click"==m){this.$element.on("click."+this.type,this.options.selector,g.proxy(this.toggle,this))
}else{if("manual"!=m){var l="hover"==m?"mouseenter":"focusin",k="hover"==m?"mouseleave":"focusout";
this.$element.on(l+"."+this.type,this.options.selector,g.proxy(this.enter,this)),this.$element.on(k+"."+this.type,this.options.selector,g.proxy(this.leave,this))
}}}this.options.selector?this._options=g.extend({},this.options,{trigger:"manual",selector:""}):this.fixTitle()
},j.prototype.getDefaults=function(){return j.DEFAULTS
},j.prototype.getOptions=function(a){return a=g.extend({},this.getDefaults(),this.$element.data(),a),a.delay&&"number"==typeof a.delay&&(a.delay={show:a.delay,hide:a.delay}),a
},j.prototype.getDelegateOptions=function(){var a={},d=this.getDefaults();
return this._options&&g.each(this._options,function(b,c){d[b]!=c&&(a[b]=c)
}),a
},j.prototype.enter=function(a){var d=a instanceof this.constructor?a:g(a.currentTarget).data("bs."+this.type);
return d||(d=new this.constructor(a.currentTarget,this.getDelegateOptions()),g(a.currentTarget).data("bs."+this.type,d)),a instanceof g.Event&&(d.inState["focusin"==a.type?"focus":"hover"]=!0),d.tip().hasClass("in")||"in"==d.hoverState?void (d.hoverState="in"):(clearTimeout(d.timeout),d.hoverState="in",d.options.delay&&d.options.delay.show?void (d.timeout=setTimeout(function(){"in"==d.hoverState&&d.show()
},d.options.delay.show)):d.show())
},j.prototype.isInStateTrue=function(){for(var b in this.inState){if(this.inState[b]){return !0
}}return !1
},j.prototype.leave=function(a){var d=a instanceof this.constructor?a:g(a.currentTarget).data("bs."+this.type);
return d||(d=new this.constructor(a.currentTarget,this.getDelegateOptions()),g(a.currentTarget).data("bs."+this.type,d)),a instanceof g.Event&&(d.inState["focusout"==a.type?"focus":"hover"]=!1),d.isInStateTrue()?void 0:(clearTimeout(d.timeout),d.hoverState="out",d.options.delay&&d.options.delay.hide?void (d.timeout=setTimeout(function(){"out"==d.hoverState&&d.hide()
},d.options.delay.hide)):d.hide())
},j.prototype.show=function(){var D=g.Event("show.bs."+this.type);
if(this.hasContent()&&this.enabled){this.$element.trigger(D);
var C=g.contains(this.$element[0].ownerDocument.documentElement,this.$element[0]);
if(D.isDefaultPrevented()||!C){return
}var B=this,A=this.tip(),z=this.getUID(this.type);
this.setContent(),A.attr("id",z),this.$element.attr("aria-describedby",z),this.options.animation&&A.addClass("fade");
var y="function"==typeof this.options.placement?this.options.placement.call(this,A[0],this.$element[0]):this.options.placement,x=/\s?auto?\s?/i,w=x.test(y);
w&&(y=y.replace(x,"")||"top"),A.detach().css({top:0,left:0,display:"block"}).addClass(y).data("bs."+this.type,this),this.options.container?A.appendTo(this.options.container):A.insertAfter(this.$element),this.$element.trigger("inserted.bs."+this.type);
var v=this.getPosition(),u=A[0].offsetWidth,t=A[0].offsetHeight;
if(w){var s=y,r=this.getPosition(this.$viewport);
y="bottom"==y&&v.bottom+t>r.bottom?"top":"top"==y&&v.top-t<r.top?"bottom":"right"==y&&v.right+u>r.width?"left":"left"==y&&v.left-u<r.left?"right":y,A.removeClass(s).addClass(y)
}var c=this.getCalculatedOffset(y,v,u,t);
this.applyPlacement(c,y);
var a=function(){var b=B.hoverState;
B.$element.trigger("shown.bs."+B.type),B.hoverState=null,"out"==b&&B.leave(B)
};
g.support.transition&&this.$tip.hasClass("fade")?A.one("bsTransitionEnd",a).emulateTransitionEnd(j.TRANSITION_DURATION):a()
}},j.prototype.applyPlacement=function(z,y){var x=this.tip(),w=x[0].offsetWidth,v=x[0].offsetHeight,u=parseInt(x.css("margin-top"),10),t=parseInt(x.css("margin-left"),10);
isNaN(u)&&(u=0),isNaN(t)&&(t=0),z.top+=u,z.left+=t,g.offset.setOffset(x[0],g.extend({using:function(b){x.css({top:Math.round(b.top),left:Math.round(b.left)})
}},z),0),x.addClass("in");
var s=x[0].offsetWidth,r=x[0].offsetHeight;
"top"==y&&r!=v&&(z.top=z.top+v-r);
var q=this.getViewportAdjustedDelta(y,z,s,r);
q.left?z.left+=q.left:z.top+=q.top;
var p=/top|bottom/.test(y),o=p?2*q.left-w+s:2*q.top-v+r,a=p?"offsetWidth":"offsetHeight";
x.offset(z),this.replaceArrow(o,x[0][a],p)
},j.prototype.replaceArrow=function(k,d,l){this.arrow().css(l?"left":"top",50*(1-k/d)+"%").css(l?"top":"left","")
},j.prototype.setContent=function(){var d=this.tip(),c=this.getTitle();
d.find(".tooltip-inner")[this.options.html?"html":"text"](c),d.removeClass("fade in top bottom left right")
},j.prototype.hide=function(a){function m(){"in"!=l.hoverState&&k.detach(),l.$element.removeAttr("aria-describedby").trigger("hidden.bs."+l.type),a&&a()
}var l=this,k=g(this.$tip),c=g.Event("hide.bs."+this.type);
return this.$element.trigger(c),c.isDefaultPrevented()?void 0:(k.removeClass("in"),g.support.transition&&k.hasClass("fade")?k.one("bsTransitionEnd",m).emulateTransitionEnd(j.TRANSITION_DURATION):m(),this.hoverState=null,this)
},j.prototype.fixTitle=function(){var b=this.$element;
(b.attr("title")||"string"!=typeof b.attr("data-original-title"))&&b.attr("data-original-title",b.attr("title")||"").attr("title","")
},j.prototype.hasContent=function(){return this.getTitle()
},j.prototype.getPosition=function(a){a=a||this.$element;
var p=a[0],o="BODY"==p.tagName,n=p.getBoundingClientRect();
null==n.width&&(n=g.extend({},n,{width:n.right-n.left,height:n.bottom-n.top}));
var m=o?{top:0,left:0}:a.offset(),l={scroll:o?document.documentElement.scrollTop||document.body.scrollTop:a.scrollTop()},k=o?{width:g(window).width(),height:g(window).height()}:null;
return g.extend({},n,l,k,m)
},j.prototype.getCalculatedOffset=function(l,k,n,m){return"bottom"==l?{top:k.top+k.height,left:k.left+k.width/2-n/2}:"top"==l?{top:k.top-m,left:k.left+k.width/2-n/2}:"left"==l?{top:k.top+k.height/2-m/2,left:k.left-n}:{top:k.top+k.height/2-m/2,left:k.left+k.width}
},j.prototype.getViewportAdjustedDelta=function(v,u,t,s){var r={top:0,left:0};
if(!this.$viewport){return r
}var q=this.options.viewport&&this.options.viewport.padding||0,p=this.getPosition(this.$viewport);
if(/right|left/.test(v)){var o=u.top-q-p.scroll,n=u.top+q-p.scroll+s;
o<p.top?r.top=p.top-o:n>p.top+p.height&&(r.top=p.top+p.height-n)
}else{var m=u.left-q,l=u.left+q+t;
m<p.left?r.left=p.left-m:l>p.right&&(r.left=p.left+p.width-l)
}return r
},j.prototype.getTitle=function(){var k,d=this.$element,l=this.options;
return k=d.attr("data-original-title")||("function"==typeof l.title?l.title.call(d[0]):l.title)
},j.prototype.getUID=function(b){do{b+=~~(1000000*Math.random())
}while(document.getElementById(b));
return b
},j.prototype.tip=function(){if(!this.$tip&&(this.$tip=g(this.options.template),1!=this.$tip.length)){throw new Error(this.type+" `template` option must consist of exactly 1 top-level element!")
}return this.$tip
},j.prototype.arrow=function(){return this.$arrow=this.$arrow||this.tip().find(".tooltip-arrow")
},j.prototype.enable=function(){this.enabled=!0
},j.prototype.disable=function(){this.enabled=!1
},j.prototype.toggleEnabled=function(){this.enabled=!this.enabled
},j.prototype.toggle=function(a){var d=this;
a&&(d=g(a.currentTarget).data("bs."+this.type),d||(d=new this.constructor(a.currentTarget,this.getDelegateOptions()),g(a.currentTarget).data("bs."+this.type,d))),a?(d.inState.click=!d.inState.click,d.isInStateTrue()?d.enter(d):d.leave(d)):d.tip().hasClass("in")?d.leave(d):d.enter(d)
},j.prototype.destroy=function(){var b=this;
clearTimeout(this.timeout),this.hide(function(){b.$element.off("."+b.type).removeData("bs."+b.type),b.$tip&&b.$tip.detach(),b.$tip=null,b.$arrow=null,b.$viewport=null
})
};
var h=g.fn.tooltip;
g.fn.tooltip=f,g.fn.tooltip.Constructor=j,g.fn.tooltip.noConflict=function(){return g.fn.tooltip=h,this
}
}(jQuery),+function(g){function f(a){return this.each(function(){var k=g(this),c=k.data("bs.popover"),b="object"==typeof a&&a;
(c||!/destroy|hide/.test(a))&&(c||k.data("bs.popover",c=new j(this,b)),"string"==typeof a&&c[a]())
})
}var j=function(d,c){this.init("popover",d,c)
};
if(!g.fn.tooltip){throw new Error("Popover requires tooltip.js")
}j.VERSION="3.3.6",j.DEFAULTS=g.extend({},g.fn.tooltip.Constructor.DEFAULTS,{placement:"right",trigger:"click",content:"",template:'<div class="popover" role="tooltip"><div class="arrow"></div><h3 class="popover-title"></h3><div class="popover-content"></div></div>'}),j.prototype=g.extend({},g.fn.tooltip.Constructor.prototype),j.prototype.constructor=j,j.prototype.getDefaults=function(){return j.DEFAULTS
},j.prototype.setContent=function(){var k=this.tip(),d=this.getTitle(),l=this.getContent();
k.find(".popover-title")[this.options.html?"html":"text"](d),k.find(".popover-content").children().detach().end()[this.options.html?"string"==typeof l?"html":"append":"text"](l),k.removeClass("fade top bottom left right in"),k.find(".popover-title").html()||k.find(".popover-title").hide()
},j.prototype.hasContent=function(){return this.getTitle()||this.getContent()
},j.prototype.getContent=function(){var d=this.$element,c=this.options;
return d.attr("data-content")||("function"==typeof c.content?c.content.call(d[0]):c.content)
},j.prototype.arrow=function(){return this.$arrow=this.$arrow||this.tip().find(".arrow")
};
var h=g.fn.popover;
g.fn.popover=f,g.fn.popover.Constructor=j,g.fn.popover.noConflict=function(){return g.fn.popover=h,this
}
}(jQuery),+function(g){function f(b,a){this.$body=g(document.body),this.$scrollElement=g(g(b).is(document.body)?window:b),this.options=g.extend({},f.DEFAULTS,a),this.selector=(this.options.target||"")+" .nav li > a",this.offsets=[],this.targets=[],this.activeTarget=null,this.scrollHeight=0,this.$scrollElement.on("scroll.bs.scrollspy",g.proxy(this.process,this)),this.refresh(),this.process()
}function j(a){return this.each(function(){var k=g(this),c=k.data("bs.scrollspy"),b="object"==typeof a&&a;
c||k.data("bs.scrollspy",c=new f(this,b)),"string"==typeof a&&c[a]()
})
}f.VERSION="3.3.6",f.DEFAULTS={offset:10},f.prototype.getScrollHeight=function(){return this.$scrollElement[0].scrollHeight||Math.max(this.$body[0].scrollHeight,document.documentElement.scrollHeight)
},f.prototype.refresh=function(){var a=this,l="offset",k=0;
this.offsets=[],this.targets=[],this.scrollHeight=this.getScrollHeight(),g.isWindow(this.$scrollElement[0])||(l="position",k=this.$scrollElement.scrollTop()),this.$body.find(this.selector).map(function(){var c=g(this),m=c.data("target")||c.attr("href"),d=/^#./.test(m)&&g(m);
return d&&d.length&&d.is(":visible")&&[[d[l]().top+k,m]]||null
}).sort(function(d,c){return d[0]-c[0]
}).each(function(){a.offsets.push(this[0]),a.targets.push(this[1])
})
},f.prototype.process=function(){var l,k=this.$scrollElement.scrollTop()+this.options.offset,q=this.getScrollHeight(),p=this.options.offset+q-this.$scrollElement.height(),o=this.offsets,n=this.targets,m=this.activeTarget;
if(this.scrollHeight!=q&&this.refresh(),k>=p){return m!=(l=n[n.length-1])&&this.activate(l)
}if(m&&k<o[0]){return this.activeTarget=null,this.clear()
}for(l=o.length;
l--;
){m!=n[l]&&k>=o[l]&&(void 0===o[l+1]||k<o[l+1])&&this.activate(n[l])
}},f.prototype.activate=function(a){this.activeTarget=a,this.clear();
var l=this.selector+'[data-target="'+a+'"],'+this.selector+'[href="'+a+'"]',k=g(l).parents("li").addClass("active");
k.parent(".dropdown-menu").length&&(k=k.closest("li.dropdown").addClass("active")),k.trigger("activate.bs.scrollspy")
},f.prototype.clear=function(){g(this.selector).parentsUntil(this.options.target,".active").removeClass("active")
};
var h=g.fn.scrollspy;
g.fn.scrollspy=j,g.fn.scrollspy.Constructor=f,g.fn.scrollspy.noConflict=function(){return g.fn.scrollspy=h,this
},g(window).on("load.bs.scrollspy.data-api",function(){g('[data-spy="scroll"]').each(function(){var a=g(this);
j.call(a,a.data())
})
})
}(jQuery),+function(g){function f(a){return this.each(function(){var c=g(this),b=c.data("bs.tab");
b||c.data("bs.tab",b=new k(this)),"string"==typeof a&&b[a]()
})
}var k=function(a){this.element=g(a)
};
k.VERSION="3.3.6",k.TRANSITION_DURATION=150,k.prototype.show=function(){var a=this.element,q=a.closest("ul:not(.dropdown-menu)"),p=a.data("target");
if(p||(p=a.attr("href"),p=p&&p.replace(/.*(?=#[^\s]*$)/,"")),!a.parent("li").hasClass("active")){var o=q.find(".active:last a"),n=g.Event("hide.bs.tab",{relatedTarget:a[0]}),m=g.Event("show.bs.tab",{relatedTarget:o[0]});
if(o.trigger(n),a.trigger(m),!m.isDefaultPrevented()&&!n.isDefaultPrevented()){var l=g(p);
this.activate(a.closest("li"),q),this.activate(l,l.parent(),function(){o.trigger({type:"hidden.bs.tab",relatedTarget:a[0]}),a.trigger({type:"shown.bs.tab",relatedTarget:o[0]})
})
}}},k.prototype.activate=function(a,o,n){function m(){l.removeClass("active").find("> .dropdown-menu > .active").removeClass("active").end().find('[data-toggle="tab"]').attr("aria-expanded",!1),a.addClass("active").find('[data-toggle="tab"]').attr("aria-expanded",!0),c?(a[0].offsetWidth,a.addClass("in")):a.removeClass("fade"),a.parent(".dropdown-menu").length&&a.closest("li.dropdown").addClass("active").end().find('[data-toggle="tab"]').attr("aria-expanded",!0),n&&n()
}var l=o.find("> .active"),c=n&&g.support.transition&&(l.length&&l.hasClass("fade")||!!o.find("> .fade").length);
l.length&&c?l.one("bsTransitionEnd",m).emulateTransitionEnd(k.TRANSITION_DURATION):m(),l.removeClass("in")
};
var j=g.fn.tab;
g.fn.tab=f,g.fn.tab.Constructor=k,g.fn.tab.noConflict=function(){return g.fn.tab=j,this
};
var h=function(a){a.preventDefault(),f.call(g(this),"show")
};
g(document).on("click.bs.tab.data-api",'[data-toggle="tab"]',h).on("click.bs.tab.data-api",'[data-toggle="pill"]',h)
}(jQuery),+function(g){function f(a){return this.each(function(){var k=g(this),c=k.data("bs.affix"),b="object"==typeof a&&a;
c||k.data("bs.affix",c=new j(this,b)),"string"==typeof a&&c[a]()
})
}var j=function(a,c){this.options=g.extend({},j.DEFAULTS,c),this.$target=g(this.options.target).on("scroll.bs.affix.data-api",g.proxy(this.checkPosition,this)).on("click.bs.affix.data-api",g.proxy(this.checkPositionWithEventLoop,this)),this.$element=g(a),this.affixed=null,this.unpin=null,this.pinnedOffset=null,this.checkPosition()
};
j.VERSION="3.3.6",j.RESET="affix affix-top affix-bottom",j.DEFAULTS={offset:0,target:window},j.prototype.getState=function(t,s,r,q){var p=this.$target.scrollTop(),o=this.$element.offset(),n=this.$target.height();
if(null!=r&&"top"==this.affixed){return r>p&&"top"
}if("bottom"==this.affixed){return null!=r?!(p+this.unpin<=o.top)&&"bottom":!(t-q>=p+n)&&"bottom"
}var m=null==this.affixed,l=m?p:o.top,k=m?n:s;
return null!=r&&r>=p?"top":null!=q&&l+k>=t-q&&"bottom"
},j.prototype.getPinnedOffset=function(){if(this.pinnedOffset){return this.pinnedOffset
}this.$element.removeClass(j.RESET).addClass("affix");
var d=this.$target.scrollTop(),c=this.$element.offset();
return this.pinnedOffset=c.top-d
},j.prototype.checkPositionWithEventLoop=function(){setTimeout(g.proxy(this.checkPosition,this),1)
},j.prototype.checkPosition=function(){if(this.$element.is(":visible")){var a=this.$element.height(),p=this.options.offset,o=p.top,n=p.bottom,m=Math.max(g(document).height(),g(document.body).height());
"object"!=typeof p&&(n=o=p),"function"==typeof o&&(o=p.top(this.$element)),"function"==typeof n&&(n=p.bottom(this.$element));
var l=this.getState(m,a,o,n);
if(this.affixed!=l){null!=this.unpin&&this.$element.css("top","");
var k="affix"+(l?"-"+l:""),c=g.Event(k+".bs.affix");
if(this.$element.trigger(c),c.isDefaultPrevented()){return
}this.affixed=l,this.unpin="bottom"==l?this.getPinnedOffset():null,this.$element.removeClass(j.RESET).addClass(k).trigger(k.replace("affix","affixed")+".bs.affix")
}"bottom"==l&&this.$element.offset({top:m-a-n})
}};
var h=g.fn.affix;
g.fn.affix=f,g.fn.affix.Constructor=j,g.fn.affix.noConflict=function(){return g.fn.affix=h,this
},g(window).on("load",function(){g('[data-spy="affix"]').each(function(){var b=g(this),a=b.data();
a.offset=a.offset||{},null!=a.offsetBottom&&(a.offset.bottom=a.offsetBottom),null!=a.offsetTop&&(a.offset.top=a.offsetTop),f.call(b,a)
})
})
}(jQuery),function(a,b){a.extend({lockfixed:function(g,f){f&&f.offset?(f.offset.bottom=parseInt(f.offset.bottom,10),f.offset.top=parseInt(f.offset.top,10)):f.offset={bottom:100,top:0};
var g=a(g);
if(g&&g.offset()){var h=g.css("position"),c=parseInt(g.css("marginTop"),10),k=g.css("top"),j=g.offset().top,d=!1;
g.wrap("<div class='lf-ghost' style='display:"+g.css("display")+"'></div>"),a(window).bind("DOMContentLoaded load scroll resize orientationchange lockfixed:pageupdate",g,function(q){if(!d||!document.activeElement||"INPUT"!==document.activeElement.nodeName){var p=0,o=g.outerHeight(),m=g.parent().innerWidth()-parseInt(g.css("marginLeft"),10)-parseInt(g.css("marginRight"),10),n=a(document).height()-f.offset.bottom,l=a(window).scrollTop();
"fixed"===g.css("position")||d||(j=g.offset().top,k=g.css("top")),l>=j-(c?c:0)-f.offset.top?(p=n<l+o+c+f.offset.top?l+o+c+f.offset.top-n:0,d?g.css({marginTop:parseInt(l-j-p,10)+2*f.offset.top+"px"}):g.css({position:"fixed",top:f.offset.top-p+"px",width:m+"px"})):g.css({position:h,top:k,width:m+"px",marginTop:(c&&!d?c:0)+"px"})
}}),a("#sub-navigation a").bind("focus",function(){try{var r=parseInt(a(window).height()),l=parseInt(this.getBoundingClientRect().top),p=parseInt(this.getBoundingClientRect().bottom),n=parseInt(a("#sub-navigation").css("top")),q=parseInt(p-l),m=parseInt(n-q);
r<p&&a("#sub-navigation").css({top:m+"px"})
}catch(o){}})
}}})
}(jQuery),!function(be,bd,bc,a7){function a6(f,d,g){return setTimeout(aY(f,g),d)
}function a4(f,d,g){return !!Array.isArray(f)&&(a3(f,g[d],g),!0)
}function a3(f,d,h){var g;
if(f){if(f.forEach){f.forEach(d,h)
}else{if(f.length!==a7){for(g=0;
g<f.length;
){d.call(h,f[g],g,f),g++
}}else{for(g in f){f.hasOwnProperty(g)&&d.call(h,f[g],g,f)
}}}}}function a2(a,h,g){var f="DEPRECATED METHOD: "+h+"\n"+g+" AT \n";
return function(){var k=new Error("get-stack-trace"),j=k&&k.stack?k.stack.replace(/^[^\(]+?[\n$]/gm,"").replace(/^\s+at\s+/gm,"").replace(/^Object.<anonymous>\s*\(/gm,"{anonymous}()@"):"Unknown Stack Trace",b=be.console&&(be.console.warn||be.console.log);
return b&&b.call(be.console,f,j),a.apply(this,arguments)
}
}function aZ(g,f,k){var j,h=f.prototype;
j=g.prototype=Object.create(h),j.constructor=g,j._super=h,k&&cj(j,k)
}function aY(d,c){return function(){return d.apply(c,arguments)
}
}function aW(d,c){return typeof d==a8?d.apply(c?c[0]||a7:a7,c):d
}function aV(d,c){return d===a7?c:d
}function aU(f,d,g){a3(aO(d),function(a){f.addEventListener(a,g,!1)
})
}function aS(f,d,g){a3(aO(d),function(a){f.removeEventListener(a,g,!1)
})
}function aR(d,c){for(;
d;
){if(d==c){return !0
}d=d.parentNode
}return !1
}function aP(d,c){return d.indexOf(c)>-1
}function aO(b){return b.trim().split(/\s+/g)
}function aN(g,f,j){if(g.indexOf&&!j){return g.indexOf(f)
}for(var h=0;
h<g.length;
){if(j&&g[h][j]==f||!j&&g[h]===f){return h
}h++
}return -1
}function aM(b){return Array.prototype.slice.call(b,0)
}function aL(j,h,o){for(var n=[],m=[],l=0;
l<j.length;
){var k=h?j[l][h]:j[l];
aN(m,k)<0&&n.push(j[l]),m[l]=k,l++
}return o&&(n=h?n.sort(function(b,d){return b[h]>d[h]
}):n.sort()),n
}function aK(h,d){for(var m,l,k=d[0].toUpperCase()+d.slice(1),j=0;
j<b4.length;
){if(m=b4[j],l=m?m+k:d,l in h){return l
}j++
}return a7
}function aJ(){return bg++
}function aI(a){var d=a.ownerDocument||a;
return d.defaultView||d.parentWindow||be
}function aH(f,d){var g=this;
this.manager=f,this.callback=d,this.element=f.element,this.target=f.options.inputTarget,this.domHandler=function(a){aW(f.options.enable,[f])&&g.handler(a)
},this.init()
}function aF(f){var d,g=f.options.inputClass;
return new (d=g?g:ac?bz:cc?bv:ap?bs:bA)(f,aE)
}function aE(j,h,o){var n=o.pointers.length,m=o.changedPointers.length,l=h&ax&&n-m===0,k=h&(ck|b5)&&n-m===0;
o.isFirst=!!l,o.isFinal=!!k,l&&(j.session={}),o.eventType=h,bT(j,o),j.emit("hammer.input",o),j.recognize(o),j.session.prevInput=o
}function bT(v,u){var t=v.session,s=u.pointers,r=s.length;
t.firstInput||(t.firstInput=bO(u)),r>1&&!t.firstMultiple?t.firstMultiple=bO(u):1===r&&(t.firstMultiple=!1);
var q=t.firstInput,p=t.firstMultiple,o=p?p.center:q.center,n=u.center=bL(s);
u.timeStamp=cm(),u.deltaTime=u.timeStamp-q.timeStamp,u.angle=bG(o,n),u.distance=bH(o,n),bR(t,u),u.offsetDirection=bI(u.deltaX,u.deltaY);
var m=bK(u.deltaTime,u.deltaX,u.deltaY);
u.overallVelocityX=m.x,u.overallVelocityY=m.y,u.overallVelocity=am(m.x)>am(m.y)?m.x:m.y,u.scale=p?bC(p.pointers,s):1,u.rotation=p?bD(p.pointers,s):0,u.maxPointers=t.prevInput?u.pointers.length>t.prevInput.maxPointers?u.pointers.length:t.prevInput.maxPointers:u.pointers.length,bQ(t,u);
var l=v.element;
aR(u.srcEvent.target,l)&&(l=u.srcEvent.target),u.target=l
}function bR(h,g){var m=g.center,l=h.offsetDelta||{},k=h.prevDelta||{},j=h.prevInput||{};
g.eventType!==ax&&j.eventType!==ck||(k=h.prevDelta={x:j.deltaX||0,y:j.deltaY||0},l=h.offsetDelta={x:m.x,y:m.y}),g.deltaX=k.x+(m.x-l.x),g.deltaY=k.y+(m.y-l.y)
}function bQ(v,u){var t,s,r,q,p=v.lastInterval||u,o=u.timeStamp-p.timeStamp;
if(u.eventType!=b5&&(o>a1||p.velocity===a7)){var n=u.deltaX-p.deltaX,m=u.deltaY-p.deltaY,d=bK(o,n,m);
s=d.x,r=d.y,t=am(d.x)>am(d.y)?d.x:d.y,q=bI(n,m),v.lastInterval=u
}else{t=p.velocity,s=p.velocityX,r=p.velocityY,q=p.direction
}u.velocity=t,u.velocityX=s,u.velocityY=r,u.direction=q
}function bO(f){for(var d=[],g=0;
g<f.pointers.length;
){d[g]={clientX:az(f.pointers[g].clientX),clientY:az(f.pointers[g].clientY)},g++
}return{timeStamp:cm(),pointers:d,center:bL(d),deltaX:f.deltaX,deltaY:f.deltaY}
}function bL(g){var f=g.length;
if(1===f){return{x:az(g[0].clientX),y:az(g[0].clientY)}
}for(var k=0,j=0,h=0;
f>h;
){k+=g[h].clientX,j+=g[h].clientY,h++
}return{x:az(k/f),y:az(j/f)}
}function bK(f,d,g){return{x:d/f||0,y:g/f||0}
}function bI(d,c){return d===c?bN:am(d)>=am(c)?0>d?a9:aA:0>c?an:cn
}function bH(g,f,k){k||(k=aD);
var j=f[k[0]]-g[k[0]],h=f[k[1]]-g[k[1]];
return Math.sqrt(j*j+h*h)
}function bG(g,f,k){k||(k=aD);
var j=f[k[0]]-g[k[0]],h=f[k[1]]-g[k[1]];
return 180*Math.atan2(h,j)/Math.PI
}function bD(d,c){return bG(c[1],c[0],aq)+bG(d[1],d[0],aq)
}function bC(d,c){return bH(c[0],c[1],aq)/bH(d[0],d[1],aq)
}function bA(){this.evEl=cd,this.evWin=bX,this.pressed=!1,aH.apply(this,arguments)
}function bz(){this.evEl=ar,this.evWin=ae,aH.apply(this,arguments),this.store=this.manager.session.pointerEvents=[]
}function by(){this.evTarget=bP,this.evWin=af,this.started=!1,aH.apply(this,arguments)
}function bx(g,f){var j=aM(g.touches),h=aM(g.changedTouches);
return f&(ck|b5)&&(j=aL(j.concat(h),"identifier",!0)),[j,h]
}function bv(){this.evTarget=bu,this.targetIds={},aH.apply(this,arguments)
}function bt(r,q){var p=aM(r.touches),o=this.targetIds;
if(q&(ax|ak)&&1===p.length){return o[p[0].identifier]=!0,[p,p]
}var n,m,l=aM(r.changedTouches),k=[],j=this.target;
if(m=p.filter(function(b){return aR(b.target,j)
}),q===ax){for(n=0;
n<m.length;
){o[m[n].identifier]=!0,n++
}}for(n=0;
n<l.length;
){o[l[n].identifier]&&k.push(l[n]),q&(ck|b5)&&delete o[l[n].identifier],n++
}return k.length?[aL(m.concat(k),"identifier",!0),k]:void 0
}function bs(){aH.apply(this,arguments);
var b=aY(this.handler,this);
this.touch=new bv(this.manager,b),this.mouse=new bA(this.manager,b),this.primaryTouch=null,this.lastTouches=[]
}function br(d,c){d&ax?(this.primaryTouch=c.changedPointers[0].identifier,bq.call(this,c)):d&(ck|b5)&&bq.call(this,c)
}function bq(g){var f=g.changedPointers[0];
if(f.identifier===this.primaryTouch){var k={x:f.clientX,y:f.clientY};
this.lastTouches.push(k);
var j=this.lastTouches,h=function(){var b=j.indexOf(k);
b>-1&&j.splice(b,1)
};
setTimeout(h,aQ)
}}function bp(j){for(var h=j.srcEvent.clientX,o=j.srcEvent.clientY,n=0;
n<this.lastTouches.length;
n++){var m=this.lastTouches[n],l=Math.abs(h-m.x),k=Math.abs(o-m.y);
if(at>=l&&at>=k){return !0
}}return !1
}function bo(d,c){this.manager=d,this.set(c)
}function bn(f){if(aP(f,av)){return av
}var d=aP(f,ai),g=aP(f,ci);
return d&&g?av:d||g?d?ai:ci:aP(f,aX)?aX:bB
}function bm(){if(!cf){return !1
}var a={},d=be.CSS&&be.CSS.supports;
return["auto","manipulation","pan-y","pan-x","pan-x pan-y","none"].forEach(function(b){a[b]=!d||be.CSS.supports("touch-action",b)
}),a
}function bl(b){this.options=cj({},this.defaults,b||{}),this.id=aJ(),this.manager=null,this.options.enable=aV(this.options.enable,!0),this.state=bJ,this.simultaneous={},this.requireFail=[]
}function bj(b){return b&b7?"cancel":b&al?"end":b&ay?"move":b&a5?"start":""
}function b6(b){return b==cn?"down":b==an?"up":b==a9?"left":b==aA?"right":""
}function bh(f,d){var g=d.manager;
return g?g.get(f):f
}function bZ(){bl.apply(this,arguments)
}function bw(){bZ.apply(this,arguments),this.pX=null,this.pY=null
}function aT(){bZ.apply(this,arguments)
}function au(){bl.apply(this,arguments),this._timer=null,this._input=null
}function ah(){bZ.apply(this,arguments)
}function cg(){bZ.apply(this,arguments)
}function b1(){bl.apply(this,arguments),this.pTime=!1,this.pCenter=!1,this._timer=null,this._input=null,this.count=0
}function bE(d,c){return c=c||{},c.recognizers=aV(c.recognizers,bE.defaults.preset),new a0(d,c)
}function a0(d,c){this.options=cj({},bE.defaults,c||{}),this.options.inputTarget=this.options.inputTarget||d,this.handlers={},this.session={},this.recognizers=[],this.oldCssProps={},this.element=d,this.input=aF(this),this.touchAction=new bo(this,this.options.touchAction),aw(this,!0),a3(this.options.recognizers,function(g){var f=this.add(new g[0](g[1]));
g[2]&&f.recognizeWith(g[2]),g[3]&&f.requireFailure(g[3])
},this)
}function aw(g,f){var j=g.element;
if(j.style){var h;
a3(g.options.cssProps,function(b,a){h=aK(j.style,a),f?(g.oldCssProps[h]=j.style[h],j.style[h]=b):j.style[h]=g.oldCssProps[h]||""
}),f||(g.oldCssProps={})
}}function aj(b,g){var f=bd.createEvent("Event");
f.initEvent(b,!0,!0),f.gesture=g,g.target.dispatchEvent(f)
}var cj,b4=["","webkit","Moz","MS","ms","o"],bM=bd.createElement("div"),a8="function",az=Math.round,am=Math.abs,cm=Date.now;
cj="function"!=typeof Object.assign?function(g){if(g===a7||null===g){throw new TypeError("Cannot convert undefined or null to object")
}for(var d=Object(g),k=1;
k<arguments.length;
k++){var j=arguments[k];
if(j!==a7&&null!==j){for(var h in j){j.hasOwnProperty(h)&&(d[h]=j[h])
}}}return d
}:Object.assign;
var b8=a2(function(g,d,k){for(var j=Object.keys(d),h=0;
h<j.length;
){(!k||k&&g[j[h]]===a7)&&(g[j[h]]=d[j[h]]),h++
}return g
},"extend","Use `assign`."),bU=a2(function(d,c){return b8(d,c,!0)
},"merge","Use `assign`."),bg=1,aC=/mobile|tablet|ip(ad|hone|od)|android/i,ap="ontouchstart" in be,ac=aK(be,"PointerEvent")!==a7,cc=ap&&aC.test(navigator.userAgent),bW="touch",ch="pen",b2="mouse",bF="kinect",a1=25,ax=1,ak=2,ck=4,b5=8,bN=1,a9=2,aA=4,an=8,cn=16,b9=a9|aA,bV=an|cn,bi=b9|bV,aD=["x","y"],aq=["clientX","clientY"];
aH.prototype={handler:function(){},init:function(){this.evEl&&aU(this.element,this.evEl,this.domHandler),this.evTarget&&aU(this.target,this.evTarget,this.domHandler),this.evWin&&aU(aI(this.element),this.evWin,this.domHandler)
},destroy:function(){this.evEl&&aS(this.element,this.evEl,this.domHandler),this.evTarget&&aS(this.target,this.evTarget,this.domHandler),this.evWin&&aS(aI(this.element),this.evWin,this.domHandler)
}};
var ad={mousedown:ax,mousemove:ak,mouseup:ck},cd="mousedown",bX="mousemove mouseup";
aZ(bA,aH,{handler:function(d){var c=ad[d.type];
c&ax&&0===d.button&&(this.pressed=!0),c&ak&&1!==d.which&&(c=ck),this.pressed&&(c&ck&&(this.pressed=!1),this.callback(this.manager,c,{pointers:[d],changedPointers:[d],pointerType:b2,srcEvent:d}))
}});
var bk={pointerdown:ax,pointermove:ak,pointerup:ck,pointercancel:b5,pointerout:b5},aG={2:bW,3:ch,4:b2,5:bF},ar="pointerdown",ae="pointermove pointerup pointercancel";
be.MSPointerEvent&&!be.PointerEvent&&(ar="MSPointerDown",ae="MSPointerMove MSPointerUp MSPointerCancel"),aZ(bz,aH,{handler:function(k){var j=this.store,q=!1,p=k.type.toLowerCase().replace("ms",""),o=bk[p],n=aG[k.pointerType]||k.pointerType,m=n==bW,l=aN(j,k.pointerId,"pointerId");
o&ax&&(0===k.button||m)?0>l&&(j.push(k),l=j.length-1):o&(ck|b5)&&(q=!0),0>l||(j[l]=k,this.callback(this.manager,o,{pointers:j,changedPointers:[k],pointerType:n,srcEvent:k}),q&&j.splice(l,1))
}});
var ce={touchstart:ax,touchmove:ak,touchend:ck,touchcancel:b5},bP="touchstart",af="touchstart touchmove touchend touchcancel";
aZ(by,aH,{handler:function(f){var d=ce[f.type];
if(d===ax&&(this.started=!0),this.started){var g=bx.call(this,f,d);
d&(ck|b5)&&g[0].length-g[1].length===0&&(this.started=!1),this.callback(this.manager,d,{pointers:g[0],changedPointers:g[1],pointerType:bW,srcEvent:f})
}}});
var bY={touchstart:ax,touchmove:ak,touchend:ck,touchcancel:b5},bu="touchstart touchmove touchend touchcancel";
aZ(bv,aH,{handler:function(f){var d=bY[f.type],g=bt.call(this,f,d);
g&&this.callback(this.manager,d,{pointers:g[0],changedPointers:g[1],pointerType:bW,srcEvent:f})
}});
var aQ=2500,at=25;
aZ(bs,aH,{handler:function(g,f,k){var j=k.pointerType==bW,h=k.pointerType==b2;
if(!(h&&k.sourceCapabilities&&k.sourceCapabilities.firesTouchEvents)){if(j){br.call(this,f,k)
}else{if(h&&bp.call(this,k)){return
}}this.callback(g,f,k)
}},destroy:function(){this.touch.destroy(),this.mouse.destroy()
}});
var ag=aK(bM.style,"touchAction"),cf=ag!==a7,b0="compute",bB="auto",aX="manipulation",av="none",ai="pan-x",ci="pan-y",b3=bm();
bo.prototype={set:function(b){b==b0&&(b=this.compute()),cf&&this.manager.element.style&&b3[b]&&(this.manager.element.style[ag]=b),this.actions=b.toLowerCase().trim()
},update:function(){this.set(this.manager.options.touchAction)
},compute:function(){var b=[];
return a3(this.manager.recognizers,function(a){aW(a.options.enable,[a])&&(b=b.concat(a.getTouchAction()))
}),bn(b.join(" "))
},preventDefaults:function(t){var s=t.srcEvent,r=t.offsetDirection;
if(this.manager.session.prevented){return void s.preventDefault()
}var q=this.actions,p=aP(q,av)&&!b3[av],o=aP(q,ci)&&!b3[ci],n=aP(q,ai)&&!b3[ai];
if(p){var m=1===t.pointers.length,l=t.distance<2,k=t.deltaTime<250;
if(m&&l&&k){return
}}return n&&o?void 0:p||o&&r&b9||n&&r&bV?this.preventSrc(s):void 0
},preventSrc:function(b){this.manager.session.prevented=!0,b.preventDefault()
}};
var bJ=1,a5=2,ay=4,al=8,cl=al,b7=16,bS=32;
bl.prototype={defaults:{},set:function(b){return cj(this.options,b),this.manager&&this.manager.touchAction.update(),this
},recognizeWith:function(d){if(a4(d,"recognizeWith",this)){return this
}var c=this.simultaneous;
return d=bh(d,this),c[d.id]||(c[d.id]=d,d.recognizeWith(this)),this
},dropRecognizeWith:function(b){return a4(b,"dropRecognizeWith",this)?this:(b=bh(b,this),delete this.simultaneous[b.id],this)
},requireFailure:function(d){if(a4(d,"requireFailure",this)){return this
}var c=this.requireFail;
return d=bh(d,this),-1===aN(c,d)&&(c.push(d),d.requireFailure(this)),this
},dropRequireFailure:function(d){if(a4(d,"dropRequireFailure",this)){return this
}d=bh(d,this);
var c=aN(this.requireFail,d);
return c>-1&&this.requireFail.splice(c,1),this
},hasRequireFailures:function(){return this.requireFail.length>0
},canRecognizeWith:function(b){return !!this.simultaneous[b.id]
},emit:function(g){function f(a){j.manager.emit(a,g)
}var j=this,h=this.state;
al>h&&f(j.options.event+bj(h)),f(j.options.event),g.additionalEvent&&f(g.additionalEvent),h>=al&&f(j.options.event+bj(h))
},tryEmit:function(b){return this.canEmit()?this.emit(b):void (this.state=bS)
},canEmit:function(){for(var b=0;
b<this.requireFail.length;
){if(!(this.requireFail[b].state&(bS|bJ))){return !1
}b++
}return !0
},recognize:function(d){var c=cj({},d);
return aW(this.options.enable,[this,c])?(this.state&(cl|b7|bS)&&(this.state=bJ),this.state=this.process(c),void (this.state&(a5|ay|al|b7)&&this.tryEmit(c))):(this.reset(),void (this.state=bS))
},process:function(b){},getTouchAction:function(){},reset:function(){}},aZ(bZ,bl,{defaults:{pointers:1},attrTest:function(d){var c=this.options.pointers;
return 0===c||d.pointers.length===c
},process:function(g){var f=this.state,k=g.eventType,j=f&(a5|ay),h=this.attrTest(g);
return j&&(k&b5||!h)?f|b7:j||h?k&ck?f|al:f&a5?f|ay:a5:bS
}}),aZ(bw,bZ,{defaults:{event:"pan",threshold:10,pointers:1,direction:bi},getTouchAction:function(){var d=this.options.direction,c=[];
return d&b9&&c.push(ci),d&bV&&c.push(ai),c
},directionTest:function(j){var h=this.options,o=!0,n=j.distance,m=j.direction,l=j.deltaX,k=j.deltaY;
return m&h.direction||(h.direction&b9?(m=0===l?bN:0>l?a9:aA,o=l!=this.pX,n=Math.abs(j.deltaX)):(m=0===k?bN:0>k?an:cn,o=k!=this.pY,n=Math.abs(j.deltaY))),j.direction=m,o&&n>h.threshold&&m&h.direction
},attrTest:function(b){return bZ.prototype.attrTest.call(this,b)&&(this.state&a5||!(this.state&a5)&&this.directionTest(b))
},emit:function(d){this.pX=d.deltaX,this.pY=d.deltaY;
var c=b6(d.direction);
c&&(d.additionalEvent=this.options.event+c),this._super.emit.call(this,d)
}}),aZ(aT,bZ,{defaults:{event:"pinch",threshold:0,pointers:2},getTouchAction:function(){return[av]
},attrTest:function(b){return this._super.attrTest.call(this,b)&&(Math.abs(b.scale-1)>this.options.threshold||this.state&a5)
},emit:function(d){if(1!==d.scale){var c=d.scale<1?"in":"out";
d.additionalEvent=this.options.event+c
}this._super.emit.call(this,d)
}}),aZ(au,bl,{defaults:{event:"press",pointers:1,time:251,threshold:9},getTouchAction:function(){return[bB]
},process:function(h){var g=this.options,l=h.pointers.length===g.pointers,k=h.distance<g.threshold,j=h.deltaTime>g.time;
if(this._input=h,!k||!l||h.eventType&(ck|b5)&&!j){this.reset()
}else{if(h.eventType&ax){this.reset(),this._timer=a6(function(){this.state=cl,this.tryEmit()
},g.time,this)
}else{if(h.eventType&ck){return cl
}}}return bS
},reset:function(){clearTimeout(this._timer)
},emit:function(b){this.state===cl&&(b&&b.eventType&ck?this.manager.emit(this.options.event+"up",b):(this._input.timeStamp=cm(),this.manager.emit(this.options.event,this._input)))
}}),aZ(ah,bZ,{defaults:{event:"rotate",threshold:0,pointers:2},getTouchAction:function(){return[av]
},attrTest:function(b){return this._super.attrTest.call(this,b)&&(Math.abs(b.rotation)>this.options.threshold||this.state&a5)
}}),aZ(cg,bZ,{defaults:{event:"swipe",threshold:10,velocity:0.3,direction:b9|bV,pointers:1},getTouchAction:function(){return bw.prototype.getTouchAction.call(this)
},attrTest:function(f){var d,g=this.options.direction;
return g&(b9|bV)?d=f.overallVelocity:g&b9?d=f.overallVelocityX:g&bV&&(d=f.overallVelocityY),this._super.attrTest.call(this,f)&&g&f.offsetDirection&&f.distance>this.options.threshold&&f.maxPointers==this.options.pointers&&am(d)>this.options.velocity&&f.eventType&ck
},emit:function(d){var c=b6(d.offsetDirection);
c&&this.manager.emit(this.options.event+c,d),this.manager.emit(this.options.event,d)
}}),aZ(b1,bl,{defaults:{event:"tap",pointers:1,taps:1,interval:300,time:250,threshold:9,posThreshold:10},getTouchAction:function(){return[aX]
},process:function(k){var j=this.options,q=k.pointers.length===j.pointers,p=k.distance<j.threshold,o=k.deltaTime<j.time;
if(this.reset(),k.eventType&ax&&0===this.count){return this.failTimeout()
}if(p&&o&&q){if(k.eventType!=ck){return this.failTimeout()
}var n=!this.pTime||k.timeStamp-this.pTime<j.interval,m=!this.pCenter||bH(this.pCenter,k.center)<j.posThreshold;
this.pTime=k.timeStamp,this.pCenter=k.center,m&&n?this.count+=1:this.count=1,this._input=k;
var l=this.count%j.taps;
if(0===l){return this.hasRequireFailures()?(this._timer=a6(function(){this.state=cl,this.tryEmit()
},j.interval,this),a5):cl
}}return bS
},failTimeout:function(){return this._timer=a6(function(){this.state=bS
},this.options.interval,this),bS
},reset:function(){clearTimeout(this._timer)
},emit:function(){this.state==cl&&(this._input.tapCount=this.count,this.manager.emit(this.options.event,this._input))
}}),bE.VERSION="2.0.8",bE.defaults={domEvents:!1,touchAction:b0,enable:!0,inputTarget:null,inputClass:null,preset:[[ah,{enable:!1}],[aT,{enable:!1},["rotate"]],[cg,{direction:b9}],[bw,{direction:b9},["swipe"]],[b1],[b1,{event:"doubletap",taps:2},["tap"]],[au]],cssProps:{userSelect:"none",touchSelect:"none",touchCallout:"none",contentZooming:"none",userDrag:"none",tapHighlightColor:"rgba(0,0,0,0)"}};
var bf=1,aB=2;
a0.prototype={set:function(b){return cj(this.options,b),b.touchAction&&this.touchAction.update(),b.inputTarget&&(this.input.destroy(),this.input.target=b.inputTarget,this.input.init()),this
},stop:function(b){this.session.stopped=b?aB:bf
},recognize:function(h){var g=this.session;
if(!g.stopped){this.touchAction.preventDefaults(h);
var m,l=this.recognizers,k=g.curRecognizer;
(!k||k&&k.state&cl)&&(k=g.curRecognizer=null);
for(var j=0;
j<l.length;
){m=l[j],g.stopped===aB||k&&m!=k&&!m.canRecognizeWith(k)?m.reset():m.recognize(h),!k&&m.state&(a5|ay|al)&&(k=g.curRecognizer=m),j++
}}},get:function(f){if(f instanceof bl){return f
}for(var d=this.recognizers,g=0;
g<d.length;
g++){if(d[g].options.event==f){return d[g]
}}return null
},add:function(d){if(a4(d,"add",this)){return this
}var c=this.get(d.options.event);
return c&&this.remove(c),this.recognizers.push(d),d.manager=this,this.touchAction.update(),d
},remove:function(f){if(a4(f,"remove",this)){return this
}if(f=this.get(f)){var d=this.recognizers,g=aN(d,f);
-1!==g&&(d.splice(g,1),this.touchAction.update())
}return this
},on:function(f,d){if(f!==a7&&d!==a7){var g=this.handlers;
return a3(aO(f),function(b){g[b]=g[b]||[],g[b].push(d)
}),this
}},off:function(f,d){if(f!==a7){var g=this.handlers;
return a3(aO(f),function(b){d?g[b]&&g[b].splice(aN(g[b],d),1):delete g[b]
}),this
}},emit:function(g,f){this.options.domEvents&&aj(g,f);
var j=this.handlers[g]&&this.handlers[g].slice();
if(j&&j.length){f.type=g,f.preventDefault=function(){f.srcEvent.preventDefault()
};
for(var h=0;
h<j.length;
){j[h](f),h++
}}},destroy:function(){this.element&&aw(this,!1),this.handlers={},this.session={},this.input.destroy(),this.element=null
}},cj(bE,{INPUT_START:ax,INPUT_MOVE:ak,INPUT_END:ck,INPUT_CANCEL:b5,STATE_POSSIBLE:bJ,STATE_BEGAN:a5,STATE_CHANGED:ay,STATE_ENDED:al,STATE_RECOGNIZED:cl,STATE_CANCELLED:b7,STATE_FAILED:bS,DIRECTION_NONE:bN,DIRECTION_LEFT:a9,DIRECTION_RIGHT:aA,DIRECTION_UP:an,DIRECTION_DOWN:cn,DIRECTION_HORIZONTAL:b9,DIRECTION_VERTICAL:bV,DIRECTION_ALL:bi,Manager:a0,Input:aH,TouchAction:bo,TouchInput:bv,MouseInput:bA,PointerEventInput:bz,TouchMouseInput:bs,SingleTouchInput:by,Recognizer:bl,AttrRecognizer:bZ,Tap:b1,Pan:bw,Swipe:cg,Pinch:aT,Rotate:ah,Press:au,on:aU,off:aS,each:a3,merge:bU,extend:b8,assign:cj,inherit:aZ,bindFn:aY,prefixed:aK});
var ao="undefined"!=typeof be?be:"undefined"!=typeof self?self:{};
ao.Hammer=bE,"function"==typeof define&&define.amd?define(function(){return bE
}):"undefined"!=typeof module&&module.exports?module.exports=bE:be[bc]=bE
}(window,document,"Hammer"),!function(){var r=window.MutationObserver||window.WebKitMutationObserver,q="ontouchstart" in window||window.DocumentTouch&&document instanceof DocumentTouch,p=void 0!==document.documentElement.style["touch-action"]||document.documentElement.style["-ms-touch-action"];
if(!p&&q&&r){window.Hammer=window.Hammer||{};
var o=/touch-action[:][\s]*(none)[^;'"]*/,n=/touch-action[:][\s]*(manipulation)[^;'"]*/,m=/touch-action/,l=!!navigator.userAgent.match(/(iPad|iPhone|iPod)/g),k=function(){try{var d=document.createElement("canvas");
return !(!window.WebGLRenderingContext||!d.getContext("webgl")&&!d.getContext("experimental-webgl"))
}catch(c){return !1
}}(),j=k&&l;
window.Hammer.time={getTouchAction:function(b){return this.checkStyleString(b.getAttribute("style"))
},checkStyleString:function(b){return m.test(b)?o.test(b)?"none":!n.test(b)||"manipulation":void 0
},shouldHammer:function(d){var c=this.hasParent(d.target);
return !(!c||j&&!(Date.now()-d.target.lastStart<125))&&c
},touchHandler:function(g){var f=g.target.getBoundingClientRect(),s=f.top!==this.pos.top||f.left!==this.pos.left,h=this.shouldHammer(g);
("none"===h||s===!1&&"manipulation"===h)&&("touchend"===g.type&&(g.target.focus(),setTimeout(function(){g.target.click()
},0)),g.preventDefault()),this.scrolled=!1,delete g.target.lastStart
},touchStart:function(b){this.pos=b.target.getBoundingClientRect(),j&&this.hasParent(b.target)&&(b.target.lastStart=Date.now())
},styleWatcher:function(b){b.forEach(this.styleUpdater,this)
},styleUpdater:function(d){if(d.target.updateNext){return void (d.target.updateNext=!1)
}var c=this.getTouchAction(d.target);
return c?void ("none"!==c&&(d.target.hadTouchNone=!1)):void (!c&&(d.oldValue&&this.checkStyleString(d.oldValue)||d.target.hadTouchNone)&&(d.target.hadTouchNone=!0,d.target.updateNext=!1,d.target.setAttribute("style",d.target.getAttribute("style")+" touch-action: none;")))
},hasParent:function(f){for(var d,g=f;
g&&g.parentNode;
g=g.parentNode){if(d=this.getTouchAction(g)){return d
}}return !1
},installStartEvents:function(){document.addEventListener("touchstart",this.touchStart.bind(this)),document.addEventListener("mousedown",this.touchStart.bind(this))
},installEndEvents:function(){document.addEventListener("touchend",this.touchHandler.bind(this),!0),document.addEventListener("mouseup",this.touchHandler.bind(this),!0)
},installObserver:function(){this.observer=new r(this.styleWatcher.bind(this)).observe(document,{subtree:!0,attributes:!0,attributeOldValue:!0,attributeFilter:["style"]})
},install:function(){this.installEndEvents(),this.installStartEvents(),this.installObserver()
}},window.Hammer.time.install()
}}(),function(a){"function"==typeof define&&define.amd?define(["jquery","hammerjs"],a):"object"==typeof exports?a(require("jquery"),require("hammerjs")):a(jQuery,Hammer)
}(function(b,a){function c(g,d){var f=b(g);
f.data("hammer")||f.data("hammer",new a(f[0],d))
}b.fn.hammer=function(d){return this.each(function(){c(this,d)
})
},a.Manager.prototype.emit=function(d){return function(f,g){d.call(this,f,g),b(this.element).trigger({type:f,gesture:g})
}
}(a.Manager.prototype.emit)
});
function showModal(a,b){$('<div class="row"><div class="col-md-12"><picture><!--[if IE 9]><video style="display: none; "><![endif]--><source srcset="'+a+'" media="(min-width: 768px) "><!--[if IE 9]></video><![endif]--><img class="img-responsive" srcset="'+b+'" alt="? "></picture></div></div>').dialog({resizable:!1,dialogClass:"responsiveDialog",modal:!0,open:function(){$("<div></div>").addClass("ui-widget-overlay").appendTo(document.body),$("body").css("overflow","hidden"),picturefill()
},close:function(c,d){$("div.ui-widget-overlay").remove(),$("body").css("overflow","auto")
}}),$(".responsiveDialog").find(":button.ui-dialog-titlebar-close").attr("aria-label","Close")
}$(function(){$(".sectioncomponent:first").addClass("first"),$(".carouselComponent .carousel").on("slide.bs.carousel",function(c){var d=$(c.relatedTarget).index(),b="#"+$(this).attr("id")+"-"+d,f="#"+$(this).attr("id")+"-disc"+d;
$("#"+$(this).attr("id")+" .carosel-disclaimer .carouseldisc:not("+f+")").fadeOut("fast",function(){$(f).fadeIn()
}),$("#"+$(this).attr("id")+" .slider_captions .caption-desc:not("+b+")").fadeOut("fast",function(){$(b).fadeIn()
})
});
var a=$("#sub-navigation").parent().width();
$("#sub-navigation").width(a),$(window).on("resize",function(){var b=$("#sub-navigation").parent().width();
$("#sub-navigation").width(b)
}),$(window).resize(function(){$("#sub-navigation").css({position:"absolute",marginTop:"-97",top:"0"}),$("#sk-sub-navigation").css({position:"absolute",marginTop:"-97",top:"0"}),$(".dockedheader").css({position:"static",width:"auto"}),$(".lf-ghost").css("display","block")
}),$.lockfixed("#sub-navigation",{offset:{top:110,bottom:460}});
$(document).on("click","#ck-banner-close",function(b,c){$("#deltaClientHeaderCookieInfo").hide(),$("#deltaClientHeaderCookieInfo").removeClass("cookieBanner")
}),$(".subnav").each(function(){var f=$(this),d=$(".styledSelect");
d.text(f.find(".options li.selected a").text());
var b=$(".options"),c=b.children("li");
d.on("click",function(g){g.stopPropagation(),$(this).toggleClass("active").next("ul.options").toggle()
}),c.click(function(g){g.stopPropagation(),d.text($(this).text()).removeClass("active"),d.find(".options li").removeClass("selected"),f.parent("li").addClass("selected"),b.hide()
}),$(document).click(function(){d.removeClass("active"),b.hide()
})
}),$(".carousel").length&&($(".carousel").hammer({domEvents:!0}).on("swipeleft",function(b){$(this).carousel("next")
}),$(".carousel").hammer({domEvents:!0}).on("swiperight",function(b){$(this).carousel("prev")
}))
});
function showCTAModal(a,b){setTimeout(function(){var d=a;
var c="";
$.ajax({url:b,dataType:"html",timeout:1000}).done(function(f){c=f;
$("body").find("#skip-content").after("<div class='ctaModal' role='dialog' aria-labelledby='modalTitle' aria-describedby='modalContent'><div class='modalHeader'><h2 id='modalTitle'>"+d+"</h2><div class='modelCloseFocus'><a href='#' class='closeModal' aria-label='Close Modal'>X</a></div></div><div class='modal-body'>"+c+"</div></div>");
$("body").find(".ctaModal").after("<div class='modal-overlay' tabindex='-1'></div>");
$(".ctaModal .showModal").attr("style","display:block;");
var j=document.querySelector(".ctaModal");
var h=document.querySelector(".modal-overlay");
if($(".modal-body").find(".carousal-chart-container")){skymilesRefresh.carosualCharts();
$(".carousal-chart").hammer({domEvents:true}).on("swipeleft",function(k){$(this).closest(".carousal-chart-container").find(".next-arrow").trigger("click")
});
$(".carousal-chart").hammer({domEvents:true}).on("swiperight",function(k){$(this).closest(".carousal-chart-container").find(".prev-arrow").trigger("click")
})
}var g=new Dialog(j,h,document.activeElement);
$(document).on("click",".closeModal",function(k){if($(".ctaModal")[0].outerHTML!=""){g.close(k)
}});
g.open()
}).fail(function(f,g){if(g==="timeout"){console.log("Failed from timeout")
}})
},2000)
}function Dialog(c,d,a){this.dialogEl=c;
this.overlayEl=d;
this.focusedElBeforeOpen=a;
var b=$(".ctaModal").find('a[href], area[href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), button:not([disabled]), [tabindex="0"]').filter(":visible");
this.focusableEls=Array.prototype.slice.call(b);
this.firstFocusableEl=this.focusableEls[0];
this.lastFocusableEl=this.focusableEls[this.focusableEls.length-1];
this.firstFocusableEl.focus()
}Dialog.prototype.open=function(){var a=this;
this.dialogEl.addEventListener("keydown",function(b){a._handleKeyDown(b)
});
this.overlayEl.addEventListener("keydown",function(){if(e.keyCode==27){a.close(e)
}});
this.firstFocusableEl.focus()
};
Dialog.prototype.close=function(a){if($("body").find(".ctaModal").length>1){for(i=0;
(i<$("body").find(".ctaModal").length-1);
i++){$("body").find(".ctaModal")[i].outerHTML=""
}for(i=0;
(i<$("body").find(".modal-overlay").length);
i++){$("body").find(".modal-overlay")[i].outerHTML=""
}}else{$("body").find(".ctaModal")[0].outerHTML="";
$("body").find(".modal-overlay")[0].outerHTML=""
}if(this.focusedElBeforeOpen){this.focusedElBeforeOpen.focus();
a.preventDefault()
}};
Dialog.prototype._handleKeyDown=function(g){var b=this;
var h=9;
var f=27;
var a=13;
function d(){if(document.activeElement===b.firstFocusableEl){g.preventDefault();
b.lastFocusableEl.focus()
}}function c(){if(document.activeElement===b.lastFocusableEl){g.preventDefault();
b.firstFocusableEl.focus()
}}switch(g.keyCode){case h:if(b.focusableEls.length===1){g.preventDefault();
break
}if(g.shiftKey){d()
}else{c()
}break;
case f:b.close();
break;
case a:if(g.currentTarget.className=="closeModal"){b.close()
}break;
default:break
}};
Dialog.prototype.addEventListeners=function(f,g){var a=this;
var c=document.querySelectorAll(f);
for(var b=0;
b<c.length;
b++){c[b].addEventListener("click",function(){a.open()
})
}var d=document.querySelectorAll(g);
for(var b=0;
b<d.length;
b++){d[b].addEventListener("click",function(){a.close()
})
}};
var skymilesRefresh={programCharts:function(){$(".rules-chart-container .table").each(function(){var a=$(this);
var b=$(".rules-chart-container").width();
columnCount=a.find("tbody tr:first").children().length;
colWidthPercentage=100/(columnCount)+"%";
if($(window).width()>767){a.find("thead tr").children().each(function(c,d){$(d).css({"min-width":0,width:colWidthPercentage})
})
}else{a.find("thead tr").children().each(function(c,d){$(d).css({"min-width":b,width:b})
})
}})
},carosualCharts:function(){$(".carousal-chart-container").each(function(){var a=$(this).find(".table");
columnCount=a.find("tbody tr:first").children().length;
colWidthPercentage=75/(columnCount-1)+"%";
width=a.find("tbody tr:first th").outerWidth(true);
if($(window).width()>767){a.find("thead tr").children().each(function(b,c){if(b>0){$(c).css({width:colWidthPercentage})
}});
a.find("tbody td").each(function(b,c){$(c).css({width:colWidthPercentage})
})
}else{a.find("thead tr").children().each(function(b,c){if(b>0){$(c).css({"min-width":width,width:width})
}});
a.find("tbody tr:first").children().each(function(b,c){if(b>0){$(c).css({"min-width":width,width:width})
}})
}$(".skymilestable tbody tr").each(function(){var d=$(this).height();
var c=$(this).find("th");
if(c!=undefined){var b=c[0].scrollHeight;
$(this).find("td").each(function(){if($(this).height()>b){b=$(this).height()
}$(this).css("height",(b)+"px")
});
if(d>b){c.css("height",((d)+1)+"px")
}else{c.css("height",((b)+1)+"px")
}}});
$(".skymilestable thead tr").each(function(){var b=$(this).height();
$(this).find("th").each(function(){if($(this).height()>b){b=$(this).height()
}$(this).css("height",((b)+1)+"px")
})
})
})
},toggleExpander:function(a){$(a.currentTarget).parent().toggleClass("open");
if($(a.currentTarget).attr("aria-expanded")=="false"){$(a.currentTarget).attr("aria-expanded","true")
}else{if($(a.currentTarget).attr("aria-expanded")=="true"){$(a.currentTarget).attr("aria-expanded","false")
}}}};
$(function(){$(".showModal").attr("style","display:none;");
var c=$(window).height()-$("#sk-sub-navigation").height()-100;
if(c>110){c=110
}$.lockfixed("#sk-sub-navigation",{offset:{top:c,bottom:460}});
$(window).resize(function(){$("#sk-sub-navigation").css({position:"absolute",marginTop:"-97",top:"0"});
$(".dockedheader").css({position:"static",width:"auto"});
$(".lf-ghost").css("display","block");
skymilesRefresh.carosualCharts();
skymilesRefresh.programCharts();
if($(window).width()<767){var d=document.querySelectorAll(".component-expander");
for(var f=0;
f<d.length;
f++){if((d[f].children[0].childElementCount>=2)){d[f].children[0].children[1].classList.remove("hideCaptionHeader")
}}}});
$(".styledSelect").attr("tabindex","0");
$(".sk-subnav").each(function(){var h=$(this);
var g=$(".styledSelect");
if(h.find(".sk-options li .grandChild a.active").text()!=""){g.text(h.find(".sk-options li .grandChild a.active").text())
}else{g.text(h.find(".sk-options li a.active").text())
}var d=$(".sk-options");
var f=$(".sk-options .child");
g.on("click",function(j){j.stopPropagation();
$(this).toggleClass("active").next("ul.sk-options").toggle()
});
f.click(function(j){j.stopPropagation();
if($(this).hasClass("single")||$(this).hasClass("parent")){$(this).find("a").addClass("active");
g.text($(this).find("a").text())
}if($(this).hasClass("open")){$(this).toggleClass("open")
}else{$(".sk-subnav").find(".open").removeClass("open");
$(this).toggleClass("open")
}});
$(document).click(function(){g.removeClass("active");
d.hide()
})
});
$(".component-faq-header").click(function(d){skymilesRefresh.toggleExpander(d)
});
$(".component-faq-header").mousedown(function(d){d.preventDefault()
});
$(".component-faq-header").keypress(function(d){if(d.which==13||d.which==32){d.preventDefault();
skymilesRefresh.toggleExpander(d)
}});
$(".component-expander-header").click(function(d){skymilesRefresh.toggleExpander(d);
skymilesRefresh.carosualCharts()
});
$(".component-expander-header").mousedown(function(d){d.preventDefault()
});
$(".component-expander-header").keypress(function(d){if(d.which==13||d.which==32){d.preventDefault();
skymilesRefresh.toggleExpander(d)
}});
var a=document.querySelectorAll(".component-expander");
for(var b=0;
b<a.length;
b++){a[b].classList.remove("open");
a[b].children[0].setAttribute("aria-expanded","false");
if((a[b].children[0].childElementCount==1)||(a[0].children[0].children[0].children[0].getAttribute("src")=="")){a[b].children[0].children[0].classList.remove("hideCaptionHeader")
}}skymilesRefresh.carosualCharts();
skymilesRefresh.programCharts();
$(document).on("click",".next-arrow",function(d){if(!(d.currentTarget.className.includes("inactive"))){d.preventDefault();
$carousalChart=$(this).closest(".carousal-chart-container").find(".carousal-chart");
var f=$carousalChart.scrollLeft();
columnWidth=$carousalChart.find("thead th").outerWidth();
columnSelected=Math.floor(f/columnWidth)+1;
scrollValue=columnWidth*(columnSelected);
$carousalChart.animate({scrollLeft:scrollValue},"slow");
$(this).prev().removeClass("inactive");
if(columnSelected+1>=$carousalChart.find("thead th").length-1){$(this).addClass("inactive")
}}});
$(document).on("click",".prev-arrow",function(d){if(!(d.currentTarget.className.includes("inactive"))){d.preventDefault();
$carousalChart=$(this).closest(".carousal-chart-container").find(".carousal-chart");
var f=$carousalChart.scrollLeft();
columnWidth=$carousalChart.find("thead th").outerWidth();
columnSelected=Math.round(f/columnWidth)-1;
scrollValue=columnWidth*(columnSelected);
$carousalChart.animate({scrollLeft:scrollValue},"slow");
$(this).next().removeClass("inactive");
if(columnSelected<1){$(this).addClass("inactive")
}}});
$(".carousal-chart").hammer({domEvents:true}).on("swipeleft",function(d){$(this).closest(".carousal-chart-container").find(".next-arrow").trigger("click")
});
$(".carousal-chart").hammer({domEvents:true}).on("swiperight",function(d){$(this).closest(".carousal-chart-container").find(".prev-arrow").trigger("click")
});
$(".r_next-arrow ").click(function(d){if(!(d.currentTarget.className.includes("inactive"))){d.preventDefault();
$rulesChart=$(this).closest(".rules-chart-container").find(".rules-chart");
var f=$rulesChart.scrollLeft();
columnWidth=$rulesChart.find("th").outerWidth();
columnSelected=Math.floor(f/columnWidth)+1;
scrollValue=columnWidth*(columnSelected);
$rulesChart.animate({scrollLeft:scrollValue},"slow");
$(this).prev().removeClass("inactive");
if(columnSelected>=$rulesChart.find("th").length-1){$(this).addClass("inactive")
}}});
$(".r_prev-arrow").click(function(d){if(!(d.currentTarget.className.includes("inactive"))){d.preventDefault();
$rulesChart=$(this).closest(".rules-chart-container").find(".rules-chart");
var f=$rulesChart.scrollLeft();
columnWidth=$rulesChart.find("th").outerWidth();
columnSelected=Math.round(f/columnWidth)-1;
scrollValue=columnWidth*(columnSelected);
$rulesChart.animate({scrollLeft:scrollValue},"slow");
$(this).next().removeClass("inactive");
if(columnSelected<1){$(this).addClass("inactive")
}}});
$(".rules-chart").hammer({domEvents:true}).on("swipeleft",function(d){$(this).closest(".rules-chart-container").find(".r_next-arrow").trigger("click")
});
$(".rules-chart").hammer({domEvents:true}).on("swiperight",function(d){$(this).closest(".rules-chart-container").find(".r_prev-arrow").trigger("click")
});
$(".styledSelect").on("keydown",function(d){if(d.keyCode==13){$(this).trigger("click")
}})
});
!function(a){"function"==typeof define&&define.amd?define(["jquery"],a):"undefined"!=typeof module&&module.exports?module.exports=a(require("jquery")):a(jQuery)
}(function(d){var h=-1,j=-1,c=function(a){return parseFloat(a)||0
},b=function(p){var q=1,l=d(p),s=null,m=[];
return l.each(function(){var r=d(this),n=r.offset().top-c(r.css("margin-top")),o=m.length>0?m[m.length-1]:null;
null===o?m.push(r):Math.floor(Math.abs(s-n))<=q?m[m.length-1]=o.add(r):m.push(r),s=n
}),m
},k=function(a){var l={byRow:!0,property:"height",target:null,remove:!1};
return"object"==typeof a?d.extend(l,a):("boolean"==typeof a?l.byRow=a:"remove"===a&&(l.remove=!0),l)
},g=d.fn.matchHeight=function(l){var m=k(l);
if(m.remove){var a=this;
return this.css(m.property,""),d.each(g._groups,function(n,o){o.elements=o.elements.not(a)
}),this
}return this.length<=1&&!m.target?this:(g._groups.push({elements:this,options:m}),g._apply(this,m),this)
};
g.version="0.7.0",g._groups=[],g._throttle=80,g._maintainScroll=!1,g._beforeUpdate=null,g._afterUpdate=null,g._rows=b,g._parse=c,g._parseOptions=k,g._apply=function(r,u){var n=k(u),m=d(r),a=[m],v=d(window).scrollTop(),q=d("html").outerHeight(!0),t=m.parents().filter(":hidden");
return t.each(function(){var l=d(this);
l.data("style-cache",l.attr("style"))
}),t.css("display","block"),n.byRow&&!n.target&&(m.each(function(){var l=d(this),p=l.css("display");
"inline-block"!==p&&"flex"!==p&&"inline-flex"!==p&&(p="block"),l.data("style-cache",l.attr("style")),l.css({display:p,"padding-top":"0","padding-bottom":"0","margin-top":"0","margin-bottom":"0","border-top-width":"0","border-bottom-width":"0",height:"100px",overflow:"hidden"})
}),a=b(m),m.each(function(){var l=d(this);
l.attr("style",l.data("style-cache")||"")
})),d.each(a,function(p,s){var l=d(s),w=0;
if(n.target){w=n.target.outerHeight(!1)
}else{if(n.byRow&&l.length<=1){return void l.css(n.property,"")
}l.each(function(){var z=d(this),A=z.attr("style"),y=z.css("display");
"inline-block"!==y&&"flex"!==y&&"inline-flex"!==y&&(y="block");
var x={display:y};
x[n.property]="",z.css(x),z.outerHeight(!1)>w&&(w=z.outerHeight(!1)),A?z.attr("style",A):z.css("display","")
})
}l.each(function(){var x=d(this),y=0;
n.target&&x.is(n.target)||("border-box"!==x.css("box-sizing")&&(y+=c(x.css("border-top-width"))+c(x.css("border-bottom-width")),y+=c(x.css("padding-top"))+c(x.css("padding-bottom"))),x.css(n.property,w-y+"px"))
})
}),t.each(function(){var l=d(this);
l.attr("style",l.data("style-cache")||null)
}),g._maintainScroll&&d(window).scrollTop(v/q*d("html").outerHeight(!0)),this
},g._applyDataApi=function(){var a={};
d("[data-match-height], [data-mh]").each(function(){var m=d(this),l=m.attr("data-mh")||m.attr("data-match-height");
l in a?a[l]=a[l].add(m):a[l]=m
}),d.each(a,function(){this.matchHeight(!0)
})
};
var f=function(a){g._beforeUpdate&&g._beforeUpdate(a,g._groups),d.each(g._groups,function(){g._apply(this.elements,this.options)
}),g._afterUpdate&&g._afterUpdate(a,g._groups)
};
g._update=function(m,l){if(l&&"resize"===l.type){var o=d(window).width();
if(o===h){return
}h=o
}m?-1===j&&(j=setTimeout(function(){f(l),j=-1
},g._throttle)):f(l)
},d(g._applyDataApi),d(window).bind("load",function(a){g._update(!1,a)
}),d(window).bind("resize orientationchange",function(a){g._update(!0,a)
})
});
$(document).on("click",".js-videoPoster",function(b){b.preventDefault();
var a=$(this);
var c=a.closest(".js-videoWrapper");
videoPlay(c)
});
function videoPlay(a){var b=a.find(".js-videoIframe");
var c=b.data("src");
a.addClass("videoWrapperActive");
b.attr("src",c)
}function videoStop(a){if(!a){var a=$(".js-videoWrapper");
var b=$(".js-videoIframe")
}else{var b=a.find(".js-videoIframe")
}a.removeClass("videoWrapperActive");
b.attr("src","")
}$(document).on("click",".details-controller",function(b){var a=$(b.target).prev(".details");
if($(a).css("display")=="block"){$(a).css("display","none");
$(b.target).removeClass("active")
}else{$(a).css("display","block");
$(b.target).addClass("active")
}if($(b.target).attr("aria-expanded")=="false"){$(b.target).attr("aria-expanded","true")
}else{if($(b.target).attr("aria-expanded")=="true"){$(b.target).attr("aria-expanded","false")
}}});
$(document).on("mousedown",".details-controller",function(a){a.preventDefault()
});
$(document).on("keypress",".details-controller",function(b){if(b.which==13||b.which==32){b.preventDefault();
var a=$(b.target).prev(".details");
if($(a).css("display")=="block"){$(a).css("display","none");
$(b.target).removeClass("active")
}else{$(a).css("display","block");
$(b.target).addClass("active")
}if($(b.target).attr("aria-expanded")=="false"){$(b.target).attr("aria-expanded","true")
}else{if($(b.target).attr("aria-expanded")=="true"){$(b.target).attr("aria-expanded","false")
}}}});